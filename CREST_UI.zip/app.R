#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
library(methutils)
library(shiny)
library(methodologydashboard)
library(shinyjs)
library(magrittr)
library(dplyr)
library(readxl)
library(stringr)
library(ggplot2)
library(cowplot)
library(jsonlite)
library(purrr)
library(data.table)
library(tictoc)
library(DBI)
library(ROracle)
library(shinybusy)
library(shinyalert)
library(forcats)
library(reshape2)
library(htmlwidgets)
library(tidyr)
library(data.table)
library(DT)
library(ggplot2)
library(plotly)
library(usmap)
library(shinydashboard)
#library(sf)
#library(tmap)
library(tigris)
library(ggspatial)

Sys.setenv(GOVUTILS_CONFIG = "PROD")
Sys.setenv(R_CONFIG_ACTIVE = "production")
library(govutils)
library(mdu)
library(data.table)
library(R6)
library(yaml)
library(crest)


ui <- function(req) {
  
  dashboard_page(
    htmltools::htmlDependency(
      name = "user_deps",
      version = "1.0.0", 
      src = "www/", 
      script = "scripts.js",
      stylesheet = "styles.css"
    ),
    shinyalert::useShinyalert(),  # Set up shinyalert
    shinybusy::use_busy_spinner(),
    title = "GO Rating Resilience Testing Tool",
    favicon = "./www/favicon.png",
    #span(img(src="favicon.png", width = 100)),
    shinyFeedback::useShinyFeedback(),
    useShinyjs(),
    ####  NavBar -----  ####
    methodology_navbar(
      brand_name = "GO Rating Resilience Testing Tool",
      menu_item(
        class = "right menu",
        a(href = "https://rscm.dev.spratingsvpc.com/ACTRS/", target="_blank", button("go_to_actrs", "ACTRS", class = "primary")),
      ),
    ),
    #### Analysis, Model, User Guide, Record Action Menu -----   #####
    menu(
      class = "ui attached pointing inverted menu",
      div(class = "ui methodology container",
      )
    ),
    ####  Sidebar -----   ####
    methodology_sidebar(
      sidebar_panel(
        div(class = "item",
            header(
              class = "white center aligned",
              size = "h3",
              title = ""
            ),

                                header(
                                    class = "white no-top-margin center aligned",
                                    size = "h1",
                                    title = "Data Selection Menu"
                                )
        ),
        #shinyjs::hidden(
        # segment(
        #   shinybusy::use_busy_spinner(),
        #   class = "centered width-95-percentage",
        #   #button("refresh_data", "Pull Latest data", class = "primary", icon("refresh")),
        #   #button("reload_data","Load data from file",class = "primary", icon("upload")),
        #   uiOutput("date_selection"),
        #   br(),
        #   br(),
        #   uiOutput("data_selection_dd"),
        # ),
        
        segment(
          class = "centered width-95-percentage",
          tags$style(HTML("
          .radio label {
            color: black !important; 
            font-weight: normal;
            margin-left: 15px;
          }
          
          
          .radio input[type='radio'] {
            margin-right: 5px;
            border: 1px solid #666;
          }
          .filter-label {
            color: black !important;
            font-weight: bold;
            margin-bottom: 14px;
            display: block;
          }
    
          .radio input[type='radio']:checked + span {
            font-weight: bold;
          }
        ")),
          methodologydashboard::header(
            class = "black no-top-margin center aligned",
            size = "h2",
            title = "Select Portfolio Type"
          ),
          div(
            class = "filter-container",
            tags$label(class = "filter-label", ""),
            select_input("portfolio_selector", label = "Select Portfolio", c("States", "Municipalities", "Counties"), clearable = FALSE)
            #select_input("portfolio_selector",label = "Select Portfolio",c("Municipalities"))
          )
        )
        
      ),
      ####  Main Panel  -----   ####
      main_panel(
        id = 'main_panel',
        class = "sidebar-width",
        shinybusy::use_busy_spinner(),
        shinybusy::use_busy_bar(),
        div(
          id = "model_content",
          step_menu(
            id = "main_steps_menu",
            class = "six",
            steps_list = list(
              list(id = "step_cover", step_class = "item",title = "Deal Universe - Meta Data",
                   
                   content = shiny::tagList(
                     strong("Note:"),
                     p(
                       "To filter the credits, please do the following:"
                     ),
                     p(
                       "1. Select the credits from the table below."
                     ),
                     p(
                       "2. Click on the Re-generate Headroom Data button and navigate to the relevant tabs to verify the data."
                     ),
                     action_button("filter_credits", "Re-generate Headroom Data"),
                     br(),
                     strong(textOutput("as_of_date")),
                     br(),
                     uiOutput("select_toggle_button"),
                     br(),
                     br(),
                     DT::dataTableOutput("go_risk_data"),
                     br(),
                     br()
                     )
              ),
             
              list(id = "step_headroom", step_class = "item",title = "Headroom Analysis Charts",
                     content = shiny::tagList(
                       methodologydashboard::header(size = "h2",
                                                    class = "main",
                                                    "Filter by State/Region"),
                       #sidebarPanel(selectizeInput("geo_filter", "Geo Filter", choices = state.name, multiple = TRUE, selected = NULL, width = '50%')),
                       column(width = 1, 
                              div(style = "display: inline-block; vertical-align: top; width: 15%;", 
                                  selectizeInput("geo_filter", "Geo Filter", choices = state.name, multiple = TRUE, width ='100%'))),
                       #column(1,align="center",selectInput(width= "150px", "eshkol",h6("x"),c("q","a","c","x"))),
                       #test <- c(state.name,".east_north_central",".east_south_central",".mid_atlantic",".midwest_region",".mountain",".new_england",".north_central_region",".northeast_region",".pacific",".south_atlantic",".south_region",".west_north_central",".west_region",".west_south_central")
                       methodologydashboard::header(size = "h2",
                                                    class = "main",
                                                    "Budget-based_reserve_as_%_Annual_Revenues_headroom_category "),
                       plotOutput("headroom_us_map_npl", height = "600px"),
                       methodologydashboard::header(size = "h2",
                                                    class = "main",
                                                    "Net Direct Debt Per Capita Headroom Category"),
                       plotOutput("headroom_us_map_nddpc", height = "600px"),
                       methodologydashboard::header(size = "h2",
                                                    class = "main",
                                                    "Cost of Debt and Liabilities Headroom Category"),
                       plotOutput("headroom_us_map_cdl", height = "600px"),
                       br(),
                       methodologydashboard::header(size = "h2",
                                                    class = "main",
                                                    "Budget-based_reserve_as_%_Annual_Revenues_headroom_category"),
                       plotOutput("headroom_graph_npl", height = "600px"),
                       methodologydashboard::header(size = "h2",
                                                    class = "main",
                                                    "Net Direct Debt Per Capita Headroom Category"),
                       plotOutput("headroom_graph_nddpc", height = "600px"),
                       methodologydashboard::header(size = "h2",
                                                    class = "main",
                                                    "Cost of Debt and Liabilities Headroom Category"),
                       plotOutput("headroom_graph_cdl", height = "600px"),
                       br()
                       )
              ), 
              
              list(id = "step_headroom_data", step_class = "item",title = "Headroom Data",
                   content = shiny::tagList(
                     strong("Note:"),
                     p(
                       "We assign Headroom Categories of High, Moderate, Low, Bottomed Out as per the following:"
                     ),
                     p(
                       "At the lowest level - Bottomed Out"
                     ),
                     p(
                       "Headroom < 30% - Low"
                     ),
                     p(
                       "Headroom >= 30% and < 60% - Moderate"
                     ),
                     p(
                       "Headroom >= 60% - High"
                     ),
                     methodologydashboard::header(size = "h2",
                                                  class = "main",
                                                  "Headroom Analysis"),
                     DT::dataTableOutput("headroom_data"),
                     br(),
                     br()
                   )
              ),
              list(id = "step_headroom_scenario_builder", step_class = "item",title = "Scenario Builder",
                   content = shiny::tagList(
                     br(),  
                     segment(  
                       class = "basic",  
                       fluidRow(
                         # Scenario Input Box
                         accordion(
                         #box(title = "1. Create New Scenario", width = 4, status = "primary", solidHeader = TRUE,
                             textInput("scen_name", "Scenario Name", placeholder = "e.g. High Debt Stress"),
                             uiOutput("builder_sliders"),
                             hr(),
                             actionButton("save_scen", "Add to Library",
                                          icon = icon("plus"),
                                          style = "width: 100%; background-color: #3498db; color: white;")),
                         #),
                         br(),
                         br(),
                         # THE LIBRARY BOX
                         #box(title = "2. Scenario Library", width = 8, status = "primary", solidHeader = TRUE,
                         accordion(
                             helpText("Build scenarios on the left, then save them here. Select scenarios to run in batch."),
                             DTOutput("library_table"),
                             hr(),
                             actionButton("run_batch", "RUN ALL SELECTED SCENARIOS",
                                          icon = icon("bolt"),
                                          style = "width: 100%; height: 50px; font-size: 18px; background-color: #2ecc71; color: white;"))
                         #)
                       ) 
             ))
                    
              ),
              list(id = "step_headroom_scenario_results", step_class = "item",title = "Batch testing results",
                   content = shiny::tagList(              
                     fluidRow(
                     valueBoxOutput("total_rows", width = 4),
                     valueBoxOutput("total_breaches", width = 4),
                     valueBoxOutput("scenarios_run", width = 4)
                   ),
                   fluidRow(
                     box(title = "Master Batch Report (All Scenarios Combined)", width = 12, status = "primary", br(),
                         DTOutput("master_table")),
                   ),
                   fluidRow(
                     box(title = "Risk Distribution Comparison - Net Direct Debt Per Capita", width = 12, status = "warning",
                         plotlyOutput("batch_dist_plot_nddpc"))
                   ),
                   fluidRow(
                     box(title = "Risk Distribution Comparison - Cost for Debt and Liabilities", width = 12, status = "warning",
                         plotlyOutput("batch_dist_plot_cdl"))
                   ),
                   fluidRow(
                     box(title = "Risk Distribution Comparison - Reserves", width = 12, status = "warning",
                         plotlyOutput("batch_dist_plot_reserves"))
                   ))
              )
              #,
              
          )
        )
      )
    ),
    methodologydashboard::footer(class = "inverted methodology vertical",
                                 segment(class = "basic center aligned",
                                         paste0(lubridate::year(Sys.Date())," Governments Ratings Methodologies: ACTRS_Methodologies@spglobal.com")))
    
    )  )
}

#' Title
#'
#' @param file_path 
#' @param input 
#' @param output 
#' @param session 
#'
#' @return
#' @export
#'
#' @examples



# Define server logic required to draw a histogram
server <- function(input, output,session) {
  
  #setwd("/home/matta_u/Ratings Resilience Headroom Tool/CreditResilienceTool")
  
  
  # GO_data_States <-
  #   read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - States")
  # 
  # GO_data_Munis <-
  #   read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Municipalities")
  # 
  # GO_data_Munis <- GO_data_Munis %>% filter (GEOID!= 0 & GEOID!= "NA" & !is.na(GEOID))
  # 
  # GO_data_Counties <-
  #   read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Counties")
  # 
  # GO_data_Counties <- GO_data_Counties %>% rename(State = state)
  # 
  # saveRDS(GO_data_States, "GO_data_States.rds")
  # saveRDS(GO_data_Munis, "GO_data_Munis.rds")
  # saveRDS(GO_data_Counties, "GO_data_Counties.rds")
  
  # Load the class
  # source("HeadroomEngine.R")
  
  CONFIG_PATH <- "./inst/goModel.yml"
  MODEL_NAME  <- "goModel"
  #SUBSECTOR   <- "States"
  
  # ==============================================================================
  # 2. CREATE MULTI-ROW INPUT TABLE (DATA.TABLE)
  # ==============================================================================
  # input_data <- data.table(
  #   `model_inputs.dpdebttaxsupdpercap` = c(1000, 1450, 2000, 3600, 4500, 4600, 100, 2500, 3500, 5000),
  #   `model_outputs.dpdebtscore`      = c(2, 2, 2, 4, 5, 6, 1, 3, 4, 5),
  #   `model_inputs.dpaicmetric`       = c(0.04, 0.055, 0.05, 0.13, 0.14, 0.16, 0.02, 0.08, 0.11, 0.16),
  #   `model_outputs.dpaicscore`       = c(2, 2, 2, 4, 5, 6, 1, 3, 4, 5),
  #   `model_inputs.flexfbpercent`     = c(0.08, 0.045, 0.03, 0.015, 0.005, 0.001, 0.10, 0.05, 0.02, 0.005),
  #   `model_outputs.flexinitscore`    = c(1, 2, 2, 3, 4, 4, 1, 2, 3, 4)
  # )
  
  GO_data_States <<-  read_xlsx("./GO/GOData.xlsx", sheet = "States")
  GO_data_Counties <<-  read_xlsx("./GO/GOData.xlsx", sheet = "Counties")
  GO_data_Munis <<-  read_xlsx("./GO/GOData.xlsx", sheet = "Municipalities")

  #GO_data <- GO_data_States
  state_choices <- reactiveVal(NULL)
  
observeEvent(input$portfolio_selector,{
  if (input$portfolio_selector == "States") {
    GO_data <- GO_data_States %>% select(c("Entity_Name","State","Analyst","ASID"))
    input_data <<- GO_data_States
    # ==============================================================================
    # 3. DEFINE SCENARIOS (USING DIRECT TECHNICAL KEYS)
    # ==============================================================================
    scenarios <- list(
      "Base Case" = list(
        "Net_Direct_Debt_Per_Capita" = 1,
        "Cost_for_Debt_and_Liabilities"         = 1,
        "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
      )
      # ,
      # 
      # "Stress: High Debt & Cost" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1.30,
      #   "Cost_for_Debt_and_Liabilities"         = 1.50,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
      # ),
      # 
      # "Stress: Low Reserves" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1,
      #   "Cost_for_Debt_and_Liabilities"         = 1,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.50
      # ),
      # 
      # "Extreme: Systemic Stress" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1.50,
      #   "Cost_for_Debt_and_Liabilities"         = 1.50,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.20
      # )
    )
    
    # ==============================================================================
    # 4. EXECUTION ENGINE
    # ==============================================================================
    engine <- risk.resilience.quantifier$new(
      config_path = CONFIG_PATH,
      target_model_name = MODEL_NAME,
      target_subsector = input$portfolio_selector
    )
    
    all_results_list <- list()
    message(paste0("Starting Scenario Analysis for sector: ", input$portfolio_selector))
    
    for (s_name in names(scenarios)) {
      message(paste0("-> Running: ", s_name))
      
      # We treat Base Case the same as others to ensure the pipeline is identical
      # 1. Create a full map (Baseline 1.0 for all metrics in config, then overlay stress)
      full_tech_map <- setNames(rep(1.0, length(engine$metrics_config)),
                                sapply(engine$metrics_config, function(x) x$metric_key))
      
      # 2. Overlay the specific multipliers from the scenario
      for (k in names(scenarios[[s_name]])) {
        full_tech_map[[k]] <- scenarios[[s_name]][[k]]
      }
      
      res <- engine$run_scenario_analysis(
        base_data = input_data,
        scenario_map = full_tech_map,
        scenario_name = s_name
      )
      
      all_results_list[[s_name]] <- res
    }
    
    master_report <<- rbindlist(all_results_list)
    setcolorder(master_report, "scenario_label")
    
    # ==============================================================================
    # 5. OUTPUT
    # ==============================================================================
    cat("\n--- MASTER SCENARIO REPORT ---\n")
    print(master_report)
    
    
    
    
    
    
    
    
    
    # GO_data <-
    #   read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx",sheet = "Headroom - States") %>% select("Entity_Name",
    #                                               "State",
    #                                               "Analyst",
    #                                               "SPID",
    #                                               "Portfolio")
    
    #GO_data <- readRDS("GO_data_States.rds") %>% select("Entity_Name", "State", "Analyst", "ASID")
    master_report$State <- as.factor(master_report$State)
    master_report$Analyst <- as.factor(master_report$Analyst)
    master_report$`Entity_Name` <- as.factor(master_report$`Entity_Name`)
    
    state_choices <- sort(unique(master_report$State))
    
    #updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = NULL)
    updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = state_choices)
    
    # Headroom Analysis - Read data and render outputs
    headroom_data <<- reactive({
      headroom_dt <- tryCatch({
        master_report
        #read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - States")
        #readRDS("GO_data_States.rds")
      }, error = function(e) {
        data.frame(
          State = character(),
          `Budget-based_reserve_as_%_Annual_Revenues_headroom_category` = character(),
          `Net_Direct_Debt_Per_Capita_headroom_category` = character(),
          `Cost_for_Debt_and_Liabilities_headroom_category` = character(),
          stringsAsFactors = FALSE
        )
      })
      headroom_dt$State <- as.factor(headroom_dt$State)
      headroom_dt$Analyst <- as.factor(headroom_dt$Analyst)
      headroom_dt$`Entity_Name` <- as.factor(headroom_dt$`Entity_Name`)
      
      headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category')
      headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category')
      headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category' <- as.factor(headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category')
      headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
      headroom_dt$'Cost_for_Debt_and_Liabilities_Score' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_Score')
      headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
      headroom_dt$'Reserves_Initial_Score' <- as.factor(headroom_dt$'Reserves_Initial_Score')
      headroom_dt$'Net_Direct_Debt_Per_Capita_headroom' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom')
      headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct')
      headroom_dt$'Cost_for_Debt_and_Liabilities_headroom' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom')
      headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct')
      
      headroom_dt
    })
    
    output$headroom_data <- DT::renderDataTable({
      DT::datatable( 
        headroom_data() %>% select( -'Portfolio',-'SPID', -'Budget-based_reserve_as_%_Annual_Revenues_headroom', -'Budget-based_reserve_as_%_Annual_Revenues_headroom_pct',
                                    -'Budget-based_reserve_as_%_Annual_Revenues_headroom_category', -'Budget-based_reserve_as_%_Annual_Revenues_status'),
        filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
        options = list(
          dom = 'Blfrtip',
          buttons = c('copy', 'excel', 'pdf'),
          scrollX = TRUE,
          paging = TRUE,
          scrollY = 400,   
          scrollCollapse = TRUE,     
          #fixedHeader = TRUE,
          fixedColumns = list(leftColumns = 3, rightColumns = 0),
          lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
          initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
          pageLength = 100)) %>%
        DT::formatRound(columns = c("Net_Direct_Debt_Per_Capita", "Net_Direct_Debt_Per_Capita_headroom",
                                    "Cost_for_Debt_and_Liabilities", "Cost_for_Debt_and_Liabilities_headroom"), digits = 4) %>%
        DT::formatPercentage(columns = c("Cost_for_Debt_and_Liabilities_headroom_pct", "Net_Direct_Debt_Per_Capita_headroom_pct"), digits = 4)
    })
    
    output$headroom_us_map_npl <- renderPlot({  
      plot.new()  
      text(x = 0.5, y = 0.5, labels = "Reserves Headroom is not calculated as it is a qualitative metric for States.", cex = 1.5)  
    })
    
    # output$headroom_us_map_npl <- renderPlot({
    #   df <- headroom_data()
    #   #browser()
    #   if (nrow(df) == 0) {
    #     return(ggplot() + 
    #              annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
    #              theme_void())
    #   }
    #   
    #   # Check for required columns
    #   if (!"State" %in% names(df) || !"Budget-based_reserve_as_%_Annual_Revenues_headroom_category" %in% names(df)) {
    #     return(ggplot() + 
    #              annotate("text", x = 0, y = 0, 
    #                       label = "Required columns not found\n(State and Budget-based_reserve_as_%_Annual_Revenues_headroom_category)", 
    #                       size = 5) +
    #              theme_void())
    #   }
    #   
    #   # Prepare data for mapping
    #   # Extract state information and category
    #   category_order <- c("High", "Moderate", "Low", "At the lowest level")
    #   map_data <- df %>%
    #     select(state_raw = State, category = `Budget-based_reserve_as_%_Annual_Revenues_headroom_category`) %>%
    #     mutate(
    #       state_raw = trimws(as.character(state_raw)),
    #       category = factor(trimws(category), levels = category_order)
    #     ) %>%
    #     filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
    #   
    #   if (nrow(map_data) == 0) {
    #     return(ggplot() + 
    #              annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
    #              theme_void())
    #   }
    #   
    #   # Try to extract state names - handle cases like "State of California" or just "California"
    #   map_data <- map_data %>%
    #     mutate(
    #       state = case_when(
    #         # If it contains "State of", extract the state name after it
    #         grepl("State of", state_raw, ignore.case = TRUE) ~ 
    #           trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
    #         # Otherwise use as is
    #         TRUE ~ state_raw
    #       )
    #     )
    #   
    #   # Create US map with color-coded categories
    #   tryCatch({
    #     # Use plot_usmap - it will automatically match state names
    #     p1 <- plot_usmap(data = map_data, values = "category", regions = "states", color = "black", labels = TRUE) +
    #       scale_fill_discrete(name = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category") +
    #       theme(
    #         legend.position = "right",
    #         legend.text = element_text(size = 10),
    #         legend.title = element_text(size = 12, face = "bold")
    #       ) + 
    #       labs(title = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category by State") + scale_fill_manual(
    #         values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
    #     
    #     return(p1)
    #   }, error = function(e) {
    #     # If plot_usmap fails, show error message with data preview
    #     state_sample <- paste(head(map_data$state, 3), collapse = ", ")
    #     ggplot() + 
    #       annotate("text", x = 0, y = 0, 
    #                label = paste0("Error creating map.\nSample states: ", state_sample, 
    #                               "\nEnsure state names match US state names or abbreviations."), 
    #                size = 4) +
    #       theme_void()
    #   })
    #   
    #   
    # })
    
    output$headroom_us_map_nddpc <- renderPlot({
      df <- headroom_data()
      #browser()
      if (nrow(df) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                 theme_void())
      }
      
      # Check for required columns
      if (!"State" %in% names(df) || !"Net_Direct_Debt_Per_Capita_headroom_category" %in% names(df)) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, 
                          label = "Required columns not found\n(State and Net_Direct_Debt_Per_Capita_headroom_category)", 
                          size = 5) +
                 theme_void())
      }
      
      # Prepare data for mapping
      # Extract state information and category
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      map_data <- df %>%
        select(state_raw = State, category = `Net_Direct_Debt_Per_Capita_headroom_category`) %>%
        mutate(
          state_raw = trimws(as.character(state_raw)),
          category = factor(trimws(category), levels = category_order)
        ) %>%
        filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
      
      if (nrow(map_data) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                 theme_void())
      }
      
      # Try to extract state names - handle cases like "State of California" or just "California"
      map_data <- map_data %>%
        mutate(
          state = case_when(
            # If it contains "State of", extract the state name after it
            grepl("State of", state_raw, ignore.case = TRUE) ~ 
              trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
            # Otherwise use as is
            TRUE ~ state_raw
          )
        )
      

      # Create US map with color-coded categories
      tryCatch({
        # Use plot_usmap - it will automatically match state names
        p2 <- plot_usmap(data = map_data, values = "category", regions = "states", color = "black", labels = TRUE) +
          scale_fill_discrete(name = "Net_Direct_Debt_Per_Capita_headroom_category") +
          theme(
            legend.position = "right",
            legend.text = element_text(size = 10),
            legend.title = element_text(size = 12, face = "bold")
          ) +
          labs(title = "Net_Direct_Debt_Per_Capita_headroom_category by State") + scale_fill_manual(
            values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
        
        return(p2)
      }, error = function(e) {
        # If plot_usmap fails, show error message with data preview
        state_sample <- paste(head(map_data$state, 3), collapse = ", ")
        ggplot() + 
          annotate("text", x = 0, y = 0, 
                   label = paste0("Error creating map.\nSample states: ", state_sample, 
                                  "\nEnsure state names match US state names or abbreviations."), 
                   size = 4) +
          theme_void()
      })
      
    })
    
    output$headroom_us_map_cdl <- renderPlot({
      df <- headroom_data()
      #browser()
      if (nrow(df) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                 theme_void())
      }
      
      # Check for required columns
      if (!"State" %in% names(df) || !"Cost_for_Debt_and_Liabilities_headroom_category" %in% names(df)) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, 
                          label = "Required columns not found\n(State and Cost_for_Debt_and_Liabilities_headroom_category)", 
                          size = 5) +
                 theme_void())
      }
      
      # Prepare data for mapping
      # Extract state information and category
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      map_data <- df %>%
        select(state_raw = State, category = `Cost_for_Debt_and_Liabilities_headroom_category`) %>%
        mutate(
          state_raw = trimws(as.character(state_raw)),
          category = factor(trimws(category), levels = category_order)
        ) %>%
        filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
      
      if (nrow(map_data) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                 theme_void())
      }
      
      # Try to extract state names - handle cases like "State of California" or just "California"
      map_data <- map_data %>%
        mutate(
          state = case_when(
            # If it contains "State of", extract the state name after it
            grepl("State of", state_raw, ignore.case = TRUE) ~ 
              trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
            # Otherwise use as is
            TRUE ~ state_raw
          )
        )
      
      # Create US map with color-coded categories
      tryCatch({
        # Use plot_usmap - it will automatically match state names
        p3 <- plot_usmap(data = map_data, values = "category", regions = "states", color = "black", labels = TRUE) +
          scale_fill_discrete(name = "Cost_for_Debt_and_Liabilities_headroom_category") +
          theme(
            legend.position = "right",
            legend.text = element_text(size = 10),
            legend.title = element_text(size = 12, face = "bold")
          ) +
          labs(title = "Cost_for_Debt_and_Liabilities_headroom_category by State") + scale_fill_manual(
            values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
        
        return(p3)
      }, error = function(e) {
        # If plot_usmap fails, show error message with data preview
        state_sample <- paste(head(map_data$state, 3), collapse = ", ")
        ggplot() + 
          annotate("text", x = 0, y = 0, 
                   label = paste0("Error creating map.\nSample states: ", state_sample, 
                                  "\nEnsure state names match US state names or abbreviations."), 
                   size = 4) +
          theme_void()
      })
      
      
    })
    
    output$headroom_graph_npl <- renderPlot({  
      plot.new()  
      text(x = 0.5, y = 0.5, labels = "Reserves Headroom is not calculated as it is a qualitative metric for States.", cex = 1.5)  
    })
    
    # output$headroom_graph_npl <- renderPlot({
    #   category_order <- c("High", "Moderate", "Low", "At the lowest level")
    #   ggplot(headroom_data(), aes(x =  factor(`Budget-based_reserve_as_%_Annual_Revenues_headroom_category`, levels = category_order))) +
    #     geom_bar(fill = "steelblue") +
    #     geom_text(
    #       stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
    #     labs(
    #       title = "",
    #       x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
    #       y = "Count"
    #     ) +
    #     theme_minimal(base_size = 10) +
    #     theme(axis.title.x = element_text(margin = margin(t = 16)),
    #           axis.text.x = element_text(margin = margin(t = 8)))    
    # }, res = 192
    # )
    output$headroom_graph_nddpc <- renderPlot({  
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      ggplot(headroom_data(), aes(x =  factor(`Net_Direct_Debt_Per_Capita_headroom_category`, levels = category_order))) +
        geom_bar(fill = "steelblue") + 
        geom_text(
          stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
        labs(
          title = "",
          x = " Net_Direct_Debt_Per_Capita_headroom_category",
          y = "Count"
        ) +
        theme_minimal(base_size = 10) +
        theme(axis.title.x = element_text(margin = margin(t = 16)),
              axis.text.x = element_text(margin = margin(t = 8)))    
    }, res = 192
    )
    output$headroom_graph_cdl <- renderPlot({
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      ggplot(headroom_data(), aes(x =  factor(`Cost_for_Debt_and_Liabilities_headroom_category`, levels = category_order))) + 
        geom_bar(fill = "steelblue") +
        geom_text(
          stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
        labs(
          title = "",
          x = " Cost_for_Debt_and_Liabilities_headroom_category",
          y = "Count"
        ) +
        theme_minimal(base_size = 10) +
        theme(axis.title.x = element_text(margin = margin(t = 16)),
              axis.text.x = element_text(margin = margin(t = 8)))    
    }, res = 192
    )
    
    
    
    
    
  }
 else if (input$portfolio_selector == "Municipalities") {
   GO_data <- GO_data_Munis %>% select(c("Entity_Name","State","Analyst","ASID"))
   input_data <<- GO_data_Munis
   # ==============================================================================
   # 3. DEFINE SCENARIOS (USING DIRECT TECHNICAL KEYS)
   # ==============================================================================
   scenarios <- list(
     "Base Case" = list(
       "Net_Direct_Debt_Per_Capita" = 1,
       "Cost_for_Debt_and_Liabilities"         = 1,
       "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
     )
     # ,
     # 
     # "Stress: High Debt & Cost" = list(
     #   "Net_Direct_Debt_Per_Capita" = 1.30,
     #   "Cost_for_Debt_and_Liabilities"         = 1.50,
     #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
     # ),
     # 
     # "Stress: Low Reserves" = list(
     #   "Net_Direct_Debt_Per_Capita" = 1,
     #   "Cost_for_Debt_and_Liabilities"         = 1,
     #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.50
     # ),
     # 
     # "Extreme: Systemic Stress" = list(
     #   "Net_Direct_Debt_Per_Capita" = 1.50,
     #   "Cost_for_Debt_and_Liabilities"         = 1.50,
     #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.20
     # )
   )
   
   # ==============================================================================
   # 4. EXECUTION ENGINE
   # ==============================================================================
   engine <- risk.resilience.quantifier$new(
     config_path = CONFIG_PATH,
     target_model_name = MODEL_NAME,
     target_subsector = input$portfolio_selector
   )
   
   all_results_list <- list()
   message(paste0("Starting Scenario Analysis for sector: ", input$portfolio_selector))
   
   for (s_name in names(scenarios)) {
     message(paste0("-> Running: ", s_name))
     
     # We treat Base Case the same as others to ensure the pipeline is identical
     # 1. Create a full map (Baseline 1.0 for all metrics in config, then overlay stress)
     full_tech_map <- setNames(rep(1.0, length(engine$metrics_config)),
                               sapply(engine$metrics_config, function(x) x$metric_key))
     
     # 2. Overlay the specific multipliers from the scenario
     for (k in names(scenarios[[s_name]])) {
       full_tech_map[[k]] <- scenarios[[s_name]][[k]]
     }
     
     res <- engine$run_scenario_analysis(
       base_data = input_data,
       scenario_map = full_tech_map,
       scenario_name = s_name
     )
     
     all_results_list[[s_name]] <- res
   }
   
   master_report <<- rbindlist(all_results_list)
   setcolorder(master_report, "scenario_label")
   
   # ==============================================================================
   # 5. OUTPUT
   # ==============================================================================
   cat("\n--- MASTER SCENARIO REPORT ---\n")
   print(master_report)
   
   master_report$State <- as.factor(master_report$State)
   master_report$Analyst <- as.factor(master_report$Analyst)
   master_report$`Entity_Name` <- as.factor(master_report$`Entity_Name`)
   
   state_choices <- sort(unique(master_report$State))
   
   #updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = NULL)
   updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = state_choices)
   
   # Headroom Analysis - Read data and render outputs
   headroom_data <<- reactive({
     headroom_dt <- tryCatch({
       master_report
       #read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Counties")
       #readRDS("GO_data_Counties.rds")
     }, error = function(e) {
       data.frame(
         `Entity_Name` = character(),
         State = character(),
         `Budget-based_reserve_as_%_Annual_Revenues_headroom_category` = character(),
         `Net_Direct_Debt_Per_Capita_headroom_category` = character(),
         `Cost_for_Debt_and_Liabilities_headroom_category` = character(),
         FIPS = character(),
         stringsAsFactors = FALSE
       )
     })
     
     headroom_dt$State <- as.factor(headroom_dt$State)
     headroom_dt$Analyst <- as.factor(headroom_dt$Analyst)
     headroom_dt$`Entity_Name` <- as.factor(headroom_dt$`Entity_Name`)
     
     headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category')
     headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category')
     headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category' <- as.factor(headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category')
     headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
     headroom_dt$'Cost_for_Debt_and_Liabilities_Score' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_Score')
     headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
     headroom_dt$'Reserves_Initial_Score' <- as.factor(headroom_dt$'Reserves_Initial_Score')
     headroom_dt$'Net_Direct_Debt_Per_Capita_headroom' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom')
     headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct')
     headroom_dt$'Cost_for_Debt_and_Liabilities_headroom' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom')
     headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct')
     
     headroom_dt
   })
   
   output$headroom_us_map_npl <- renderPlot({  
     plot.new()  
     text(x = 0.5, y = 0.5, labels = "US Mapping for Municipalities is currently not supported in the tool.", cex = 1.5)  
   })
   
   output$headroom_us_map_nddpc <- renderPlot({  
     plot.new()  
     text(x = 0.5, y = 0.5, labels = "US Mapping for Municipalities is currently not supported in the tool.", cex = 1.5)  
   })
   
   output$headroom_us_map_cdl <- renderPlot({  
     plot.new()  
     text(x = 0.5, y = 0.5, labels = "US Mapping for Municipalities is currently not supported in the tool.", cex = 1.5)  
   })
   
   output$headroom_data <- DT::renderDataTable({
     DT::datatable(
       headroom_data() %>% select( -'Portfolio',-'SPID'),
       filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
       #%>% mutate('Net_Direct_Debt_Per_Capita_Score' = as.factor('Net_Direct_Debt_Per_Capita_Score')),
       options = list(
         dom = 'Blfrtip',
         buttons = c('copy', 'excel', 'pdf'),
         scrollX = TRUE,
         paging = TRUE,
         scrollY = 400,
         scrollCollapse = TRUE,
         #fixedHeader = TRUE,
         fixedColumns = list(leftColumns = 3, rightColumns = 0),
         lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
         initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
         pageLength = 100)) %>%
       DT::formatRound(columns = c("Net_Direct_Debt_Per_Capita", "Net_Direct_Debt_Per_Capita_headroom", "Budget_based_reserve_as_pct_Annual_Revenues", 
                                    "Cost_for_Debt_and_Liabilities", "Cost_for_Debt_and_Liabilities_headroom", "Budget-based_reserve_as_%_Annual_Revenues_headroom"), digits = 4) %>%
       DT::formatPercentage(columns = c("Cost_for_Debt_and_Liabilities_headroom_pct", "Budget-based_reserve_as_%_Annual_Revenues_headroom_pct",
                                          "Net_Direct_Debt_Per_Capita_headroom_pct" ), digits = 4)
   })
   
   output$headroom_graph_npl <- renderPlot({
     category_order <- c("High", "Moderate", "Low", "At the lowest level")
     ggplot(headroom_data(), aes(x =  factor(`Budget-based_reserve_as_%_Annual_Revenues_headroom_category`, levels = category_order))) +
       geom_bar(fill = "steelblue") +
       geom_text(
         stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
       labs(
         title = "",
         x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
         y = "Count"
       ) +
       theme_minimal(base_size = 10) +
       theme(axis.title.x = element_text(margin = margin(t = 16)),
             axis.text.x = element_text(margin = margin(t = 8)))    
   }, res = 192
   )
   
   output$headroom_graph_nddpc <- renderPlot({  
     category_order <- c("High", "Moderate", "Low", "At the lowest level")
     ggplot(headroom_data(), aes(x =  factor(`Net_Direct_Debt_Per_Capita_headroom_category`, levels = category_order))) +
       geom_bar(fill = "steelblue") + geom_text(
         stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
       labs(
         title = "",
         x = " Net_Direct_Debt_Per_Capita_headroom_category",
         y = "Count"
       ) +
       theme_minimal(base_size = 10) +
       theme(axis.title.x = element_text(margin = margin(t = 16)),
             axis.text.x = element_text(margin = margin(t = 8)))    
   }, res = 192
   )
   
   output$headroom_graph_cdl <- renderPlot({
     category_order <- c("High", "Moderate", "Low", "At the lowest level")
     ggplot(headroom_data(), aes(x =  factor(`Cost_for_Debt_and_Liabilities_headroom_category`, levels = category_order))) + 
       geom_bar(fill = "steelblue") +
       geom_text(
         stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
       labs(
         title = "",
         x = " Cost_for_Debt_and_Liabilities_headroom_category",
         y = "Count"
       ) +
       theme_minimal(base_size = 10) +
       theme(axis.title.x = element_text(margin = margin(t = 16)),
             axis.text.x = element_text(margin = margin(t = 8)))    
   }, res = 192
   )
   
   
 }
  
 else{
    # GO_data <-
    #   read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx",sheet = "Headroom - Counties") %>% select("Entity_Name",
    #                                                                                            "state",
    #                                                                                            "Analyst",
    #                                                                                            "SPID",
    #                                                                                            "ASID",
    #                                                                                            "Portfolio")

  GO_data <- GO_data_Counties %>% select(c("Entity_Name","State","Analyst","ASID"))
    input_data <<- GO_data_Counties
    # ==============================================================================
    # 3. DEFINE SCENARIOS (USING DIRECT TECHNICAL KEYS)
    # ==============================================================================
    scenarios <- list(
      "Base Case" = list(
        "Net_Direct_Debt_Per_Capita" = 1,
        "Cost_for_Debt_and_Liabilities"         = 1,
        "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
      )
      # ,
      # 
      # "Stress: High Debt & Cost" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1.30,
      #   "Cost_for_Debt_and_Liabilities"         = 1.50,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
      # ),
      # 
      # "Stress: Low Reserves" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1,
      #   "Cost_for_Debt_and_Liabilities"         = 1,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.50
      # ),
      # 
      # "Extreme: Systemic Stress" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1.50,
      #   "Cost_for_Debt_and_Liabilities"         = 1.50,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.20
      # )
    )
    
    # ==============================================================================
    # 4. EXECUTION ENGINE
    # ==============================================================================
    engine <- risk.resilience.quantifier$new(
      config_path = CONFIG_PATH,
      target_model_name = MODEL_NAME,
      target_subsector = input$portfolio_selector
    )
    
    all_results_list <- list()
    message(paste0("Starting Scenario Analysis for sector: ", input$portfolio_selector))
    
    for (s_name in names(scenarios)) {
      message(paste0("-> Running: ", s_name))
      
      # We treat Base Case the same as others to ensure the pipeline is identical
      # 1. Create a full map (Baseline 1.0 for all metrics in config, then overlay stress)
      full_tech_map <- setNames(rep(1.0, length(engine$metrics_config)),
                                sapply(engine$metrics_config, function(x) x$metric_key))
      
      # 2. Overlay the specific multipliers from the scenario
      for (k in names(scenarios[[s_name]])) {
        full_tech_map[[k]] <- scenarios[[s_name]][[k]]
      }
      
      res <- engine$run_scenario_analysis(
        base_data = input_data,
        scenario_map = full_tech_map,
        scenario_name = s_name
      )
      
      all_results_list[[s_name]] <- res
    }
    
    master_report <<- rbindlist(all_results_list)
    setcolorder(master_report, "scenario_label")
    
    # ==============================================================================
    # 5. OUTPUT
    # ==============================================================================
    cat("\n--- MASTER SCENARIO REPORT ---\n")
    print(master_report)

    
    # GO_data <-
    #   read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx",sheet = "Headroom - Counties") %>% select("Entity_Name",
    #                                                                                            "state",
    #                                                                                            "Analyst",
    #                                                                                            "SPID",
    #                                                                                            "ASID",
    #                                                                                            "Portfolio")
    
    #GO_data <- readRDS("GO_data_Counties.rds") %>% select("Entity_Name", "State", "Analyst", "ASID")
    master_report$State <- as.factor(master_report$State)
    master_report$Analyst <- as.factor(master_report$Analyst)
    master_report$`Entity_Name` <- as.factor(master_report$`Entity_Name`)
    
    state_choices <- sort(unique(master_report$State))
    
    #updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = NULL)
    updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = state_choices)
    
    # Headroom Analysis - Read data and render outputs
    headroom_data <<- reactive({
      headroom_dt <- tryCatch({
        master_report
        #read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Counties")
        #readRDS("GO_data_Counties.rds")
      }, error = function(e) {
        data.frame(
          `Entity_Name` = character(),
           State = character(),
          `Budget-based_reserve_as_%_Annual_Revenues_headroom_category` = character(),
          `Net_Direct_Debt_Per_Capita_headroom_category` = character(),
          `Cost_for_Debt_and_Liabilities_headroom_category` = character(),
           FIPS = character(),
          stringsAsFactors = FALSE
        )
      })
      
      headroom_dt$State <- as.factor(headroom_dt$State)
      headroom_dt$Analyst <- as.factor(headroom_dt$Analyst)
      headroom_dt$`Entity_Name` <- as.factor(headroom_dt$`Entity_Name`)
      
      headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category')
      headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category')
      headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category' <- as.factor(headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category')
      headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
      headroom_dt$'Cost_for_Debt_and_Liabilities_Score' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_Score')
      headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
      headroom_dt$'Reserves_Initial_Score' <- as.factor(headroom_dt$'Reserves_Initial_Score')
      headroom_dt$'Net_Direct_Debt_Per_Capita_headroom' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom')
      headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct')
      headroom_dt$'Cost_for_Debt_and_Liabilities_headroom' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom')
      headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct')
      
      headroom_dt
    })
    
    output$headroom_us_map_npl <- renderPlot({
      df <- headroom_data()
      if (nrow(df) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                 theme_void())
      }
      
      # Check for required columns
      if (!"FIPS" %in% names(df) || !"Budget-based_reserve_as_%_Annual_Revenues_headroom_category" %in% names(df)) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, 
                          label = "Required columns not found\n(FIPS and Budget-based_reserve_as_%_Annual_Revenues_headroom_category)", 
                          size = 5) +
                 theme_void())
      }
      
      # Prepare data for mapping
      # Extract state information and category
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      map_data <- df %>%
        select(fips = `FIPS`, state_raw = State, category = `Budget-based_reserve_as_%_Annual_Revenues_headroom_category`) %>%
        mutate(
          fips = as.character(fips),
          state_raw = trimws(as.character(state_raw)),
          category = factor(trimws(category), levels = category_order)
        ) %>%
        filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
      
      if (nrow(map_data) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                 theme_void())
      }
      
      # Try to extract state names - handle cases like "State of California" or just "California"
      map_data <- map_data %>%
        mutate(
          state = case_when(
            # If it contains "State of", extract the state name after it
            grepl("State of", state_raw, ignore.case = TRUE) ~ 
              trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
            # Otherwise use as is
            TRUE ~ state_raw
          )
        )
      
      
      county_data <- usmap::countypop %>% select(fips)  %>%  left_join(map_data, by = 'fips')
      
      # Create US map with color-coded categories
      tryCatch({
        # Use plot_usmap - it will automatically match state names
        p1 <- plot_usmap(data = map_data, values = "category", regions = "counties", color = "black") +
          scale_fill_discrete(name = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category") +
          theme(
            legend.position = "right",
            legend.text = element_text(size = 10),
            legend.title = element_text(size = 12, face = "bold")
          ) +
          labs(title = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category by County") + scale_fill_manual(
            values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
        
        return(p1)
      }, error = function(e) {
        # If plot_usmap fails, show error message with data preview
        state_sample <- paste(head(map_data$state, 3), collapse = ", ")
        ggplot() + 
          annotate("text", x = 0, y = 0, 
                   label = paste0("Error creating map.\nSample states: ", state_sample, 
                                  "\nEnsure state names match US state names or abbreviations."), 
                   size = 4) +
          theme_void()
      })
      
      
    })
    
    output$headroom_us_map_nddpc <- renderPlot({
      df <- headroom_data()
      if (nrow(df) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                 theme_void())
      }
      
      # Check for required columns
      if (!"FIPS" %in% names(df) || !"Net_Direct_Debt_Per_Capita_headroom_category" %in% names(df)) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, 
                          label = "Required columns not found\n(FIPS and Net_Direct_Debt_Per_Capita_headroom_category)", 
                          size = 5) +
                 theme_void())
      }
      
      # Prepare data for mapping
      # Extract state information and category
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      map_data <- df %>%
        select(fips = `FIPS`, state_raw = State, category = `Net_Direct_Debt_Per_Capita_headroom_category`) %>%
        mutate(
          fips = as.character(fips),
          state_raw = trimws(as.character(state_raw)),
          category = factor(trimws(category), levels = category_order)
        ) %>%
        filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
      
      if (nrow(map_data) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                 theme_void())
      }
      
      # Try to extract state names - handle cases like "State of California" or just "California"
      map_data <- map_data %>%
        mutate(
          state = case_when(
            # If it contains "State of", extract the state name after it
            grepl("State of", state_raw, ignore.case = TRUE) ~ 
              trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
            # Otherwise use as is
            TRUE ~ state_raw
          )
        )
      
      
      county_data <- usmap::countypop %>% select(fips)  %>%  left_join(map_data, by = 'fips')
      
      # Create US map with color-coded categories
      tryCatch({
        # Use plot_usmap - it will automatically match state names
        p1 <- plot_usmap(data = map_data, values = "category", regions = "counties", color = "black") +
          scale_fill_discrete(name = "Net_Direct_Debt_Per_Capita_headroom_category") +
          theme(
            legend.position = "right",
            legend.text = element_text(size = 10),
            legend.title = element_text(size = 12, face = "bold")
          ) +
          labs(title = "Net_Direct_Debt_Per_Capita_headroom_category by County") + scale_fill_manual(
            values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
        
        return(p1)
      }, error = function(e) {
        # If plot_usmap fails, show error message with data preview
        state_sample <- paste(head(map_data$state, 3), collapse = ", ")
        ggplot() + 
          annotate("text", x = 0, y = 0, 
                   label = paste0("Error creating map.\nSample states: ", state_sample, 
                                  "\nEnsure state names match US state names or abbreviations."), 
                   size = 4) +
          theme_void()
      })
      
      
    })
    
    output$headroom_us_map_cdl <- renderPlot({
      df <- headroom_data()
      if (nrow(df) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                 theme_void())
      }
      
      # Check for required columns
      if (!"FIPS" %in% names(df) || !"Cost_for_Debt_and_Liabilities_headroom_category" %in% names(df)) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, 
                          label = "Required columns not found\n(FIPS and Cost_for_Debt_and_Liabilities_headroom_category)", 
                          size = 5) +
                 theme_void())
      }
      
      # Prepare data for mapping
      # Extract state information and category
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      map_data <- df %>%
        select(fips = `FIPS`, state_raw = State, category = `Cost_for_Debt_and_Liabilities_headroom_category`) %>%
        mutate(
          fips = as.character(fips),
          state_raw = trimws(as.character(state_raw)),
          category = factor(trimws(category), levels = category_order)
        ) %>%
        filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
     
      if (nrow(map_data) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                 theme_void())
      }
      
      # Try to extract state names - handle cases like "State of California" or just "California"
      map_data <- map_data %>%
        mutate(
          state = case_when(
            # If it contains "State of", extract the state name after it
            grepl("State of", state_raw, ignore.case = TRUE) ~ 
              trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
            # Otherwise use as is
            TRUE ~ state_raw
          )
        )
      
      
      county_data <- usmap::countypop %>% select(fips)  %>%  left_join(map_data, by = 'fips')
      
      # Create US map with color-coded categories
      tryCatch({
        # Use plot_usmap - it will automatically match state names
        p1 <- plot_usmap(data = map_data, values = "category", regions = "counties", color = "black") +
          scale_fill_discrete(name = "Cost_for_Debt_and_Liabilities_headroom_category") +
          theme(
            legend.position = "right",
            legend.text = element_text(size = 10),
            legend.title = element_text(size = 12, face = "bold")
          ) +
          labs(title = "Cost_for_Debt_and_Liabilities_headroom_category by County") + scale_fill_manual(
            values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
        
        return(p1)
      }, error = function(e) {
        # If plot_usmap fails, show error message with data preview
        state_sample <- paste(head(map_data$state, 3), collapse = ", ")
        ggplot() + 
          annotate("text", x = 0, y = 0, 
                   label = paste0("Error creating map.\nSample states: ", state_sample, 
                                  "\nEnsure state names match US state names or abbreviations."), 
                   size = 4) +
          theme_void()
      })
      
      
    })
    
    
    output$headroom_data <- DT::renderDataTable({
      DT::datatable( 
        headroom_data() %>% select( -'Portfolio',-'SPID'),
        filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
        options = list(
          dom = 'Blfrtip',
          buttons = c('copy', 'excel', 'pdf'),
          scrollX = TRUE,
          paging = TRUE,
          scrollY = 400,   
          scrollCollapse = TRUE,     
          #fixedHeader = TRUE,
          fixedColumns = list(leftColumns = 3, rightColumns = 0),
          lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
          initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
          pageLength = 100)) %>% 
        DT::formatRound(columns = c("Net_Direct_Debt_Per_Capita", "Net_Direct_Debt_Per_Capita_headroom", "Budget_based_reserve_as_pct_Annual_Revenues", 
                                    "Cost_for_Debt_and_Liabilities", "Cost_for_Debt_and_Liabilities_headroom", "Budget-based_reserve_as_%_Annual_Revenues_headroom"), digits = 4) %>%
        DT::formatPercentage(columns = c( "Cost_for_Debt_and_Liabilities_headroom_pct", "Budget-based_reserve_as_%_Annual_Revenues_headroom_pct",
                                          "Net_Direct_Debt_Per_Capita_headroom_pct" ), digits = 4)
    })
    
    output$headroom_graph_npl <- renderPlot({
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      ggplot(headroom_data(), aes(x =  factor(`Budget-based_reserve_as_%_Annual_Revenues_headroom_category`, levels = category_order))) +
        geom_bar(fill = "steelblue") +
        geom_text(
          stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
        labs(
          title = "",
          x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
          y = "Count"
        ) +
        theme_minimal(base_size = 10) +
        theme(axis.title.x = element_text(margin = margin(t = 16)),
              axis.text.x = element_text(margin = margin(t = 8)))    
    }, res = 192
    )
    
    output$headroom_graph_nddpc <- renderPlot({  
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      ggplot(headroom_data(), aes(x =  factor(`Net_Direct_Debt_Per_Capita_headroom_category`, levels = category_order))) +
        geom_bar(fill = "steelblue") + geom_text(
          stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
        labs(
          title = "",
          x = " Net_Direct_Debt_Per_Capita_headroom_category",
          y = "Count"
        ) +
        theme_minimal(base_size = 10) +
        theme(axis.title.x = element_text(margin = margin(t = 16)),
              axis.text.x = element_text(margin = margin(t = 8)))    
    }, res = 192
    )
    
    output$headroom_graph_cdl <- renderPlot({
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      ggplot(headroom_data(), aes(x =  factor(`Cost_for_Debt_and_Liabilities_headroom_category`, levels = category_order))) + 
        geom_bar(fill = "steelblue") +
        geom_text(
          stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
        labs(
          title = "",
          x = " Cost_for_Debt_and_Liabilities_headroom_category",
          y = "Count"
        ) +
        theme_minimal(base_size = 10) +
        theme(axis.title.x = element_text(margin = margin(t = 16)),
              axis.text.x = element_text(margin = margin(t = 8)))    
    }, res = 192
    )
    
    
 }
  output$go_risk_data <- DT::renderDataTable(
    DT::datatable(GO_data, filter = 'top', rownames = FALSE, extensions = c('Select','Buttons'),
                  selection = 'none',
                  options = list(
    dom = 'Blfrtip',
    select = list(style = 'multi', items = 'row'),
    buttons = list(list(
                extend = 'selectAll',
                text = 'Select all',
                action = DT::JS(
                  "function (e, dt, node, config) {
                       dt.rows({ page: 'current' }).select();
                     }"
                )
              ),'selectNone','copy', 'excel', 'pdf' 
                ),
    scrollX = TRUE,
    paging = TRUE,
    lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
    #initComplete = initComplete_selc_deselc,
    #initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
    pageLength = 100)), server = FALSE)

  })

  # Switch to Deal Universe tab when portfolio selector button is clicked
  observeEvent(input$portfolio_selector,{     
    update_tabset(session, "main_steps_menu", selected = "step_cover")
  })
  
 
# Filtering credits 
  
  observeEvent(input$filter_credits, {
    shinybusy::show_modal_progress_line()
    shinybusy::show_modal_spinner(
      spin = "cube-grid",
      color = "firebrick",
      text = "Fetching Headroom Data..."
    )
    # if (input$portfolio_selector == "States") {displayed_data <- read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - States")}
    # else if (input$portfolio_selector == "Municipalities") {displayed_data <- read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Municipalities")}
    # else {displayed_data <- read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Counties")}
    
    if (input$portfolio_selector == "States") {displayed_data <- GO_data_States}
    else if (input$portfolio_selector == "Municipalities") {displayed_data <- GO_data_Munis}
    else {displayed_data <- GO_data_Counties}
    
    #selected_rows <- input$go_risk_data_rows_selected

    #req(input$go_risk_data_rows_selected)
    #rows_selection <- input$go_risk_data_rows_all[input$go_risk_data_rows_selected]
    
    rows_selection <- input$go_risk_data_rows_selected
    if(is.null(rows_selection)){
      selected_asids <- displayed_data
    }
    else{
      selected_asids <- displayed_data[rows_selection, "ASID", drop = TRUE]
    }
    
    data_to_use <- reactive({
      if(length(rows_selection) == 0) {
        displayed_data
      } else {
        displayed_data[displayed_data$ASID %in% selected_asids, ]
      }
    })
    
    input_data_filtered <- data_to_use()
    #browser()
    
    # ==============================================================================
    # 3. DEFINE SCENARIOS (USING DIRECT TECHNICAL KEYS)
    # ==============================================================================
    scenarios <- list(
      "Base Case" = list(
        "Net_Direct_Debt_Per_Capita" = 1,
        "Cost_for_Debt_and_Liabilities"         = 1,
        "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
      )
      # ,
      # 
      # "Stress: High Debt & Cost" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1.30,
      #   "Cost_for_Debt_and_Liabilities"         = 1.50,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
      # ),
      # 
      # "Stress: Low Reserves" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1,
      #   "Cost_for_Debt_and_Liabilities"         = 1,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.50
      # ),
      # 
      # "Extreme: Systemic Stress" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1.50,
      #   "Cost_for_Debt_and_Liabilities"         = 1.50,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.20
      # )
    )
    
    # ==============================================================================
    # 4. EXECUTION ENGINE
    # ==============================================================================
    engine <- risk.resilience.quantifier$new(
      config_path = CONFIG_PATH,
      target_model_name = MODEL_NAME,
      target_subsector = input$portfolio_selector
    )
    
    all_results_list <- list()
    message(paste0("Starting Scenario Analysis for sector: ", input$portfolio_selector))
    
    for (s_name in names(scenarios)) {
      message(paste0("-> Running: ", s_name))
      
      # We treat Base Case the same as others to ensure the pipeline is identical
      # 1. Create a full map (Baseline 1.0 for all metrics in config, then overlay stress)
      full_tech_map <- setNames(rep(1.0, length(engine$metrics_config)),
                                sapply(engine$metrics_config, function(x) x$metric_key))
      
      # 2. Overlay the specific multipliers from the scenario
      for (k in names(scenarios[[s_name]])) {
        full_tech_map[[k]] <- scenarios[[s_name]][[k]]
      }
      
      res <- engine$run_scenario_analysis(
        base_data = input_data_filtered,
        scenario_map = full_tech_map,
        scenario_name = s_name
      )
      
      all_results_list[[s_name]] <- res
    }
    
    master_report <<- rbindlist(all_results_list)
    setcolorder(master_report, "scenario_label")
    
    # ==============================================================================
    # 5. OUTPUT
    # ==============================================================================
    cat("\n--- MASTER SCENARIO REPORT FILTERED CREDITS ---\n")
    print(master_report)
    
    # data_to_use <- reactive({
    #   if(length(selected_asids) == 0) {
    #     master_report
    #   } else {
    #     master_report[master_report$ASID %in% selected_asids, ]
    #   }
    # })
    # 
    
    if (input$portfolio_selector == "States") {
    # Headroom Analysis - Read data and render outputs
    headroom_data <<- reactive({
      headroom_dt <- tryCatch({
        #read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - States")
        #data_to_use()
        master_report
      }, error = function(e) {
        data.frame(
          #State = character(),
          State = factor(),
          `Budget-based_reserve_as_%_Annual_Revenues_headroom_category` = character(),
          `Net_Direct_Debt_Per_Capita_headroom_category` = character(),
          `Cost_for_Debt_and_Liabilities_headroom_category` = character(),
          stringsAsFactors = FALSE
        )
      })
      
      headroom_dt$State <- as.factor(headroom_dt$State)
      headroom_dt$Analyst <- as.factor(headroom_dt$Analyst)
      headroom_dt$`Entity_Name` <- as.factor(headroom_dt$`Entity_Name`)
      
      headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category')
      headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category')
      headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category' <- as.factor(headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category')
      headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
      headroom_dt$'Cost_for_Debt_and_Liabilities_Score' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_Score')
      headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
      headroom_dt$'Reserves_Initial_Score' <- as.factor(headroom_dt$'Reserves_Initial_Score')
      headroom_dt$'Net_Direct_Debt_Per_Capita_headroom' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom')
      headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct')
      headroom_dt$'Cost_for_Debt_and_Liabilities_headroom' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom')
      headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct')
      
      headroom_dt
    })
    
    state_choices <- sort(unique(data_to_use()$State))
    
    #updateSelectizeInput(session, "geo_filter", "Geo Filter", selected = NULL)
    #updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = NULL)
    
    updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = state_choices)
    
    output$headroom_data <- DT::renderDataTable({
      DT::datatable( 
        headroom_data() %>% select( -'Portfolio',-'SPID', -'Budget-based_reserve_as_%_Annual_Revenues_headroom', -'Budget-based_reserve_as_%_Annual_Revenues_headroom_pct',
                                    -'Budget-based_reserve_as_%_Annual_Revenues_headroom_category', -'Budget-based_reserve_as_%_Annual_Revenues_status'),
        filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
        options = list(
          dom = 'Blfrtip',
          buttons = c('copy', 'excel', 'pdf'),
          scrollX = TRUE,
          paging = TRUE,
          scrollY = 400,   
          scrollCollapse = TRUE,     
          #fixedHeader = TRUE,
          fixedColumns = list(leftColumns = 3, rightColumns = 0),
          lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
          initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
          pageLength = 100)) %>% 
        DT::formatRound(columns = c("Net_Direct_Debt_Per_Capita", "Net_Direct_Debt_Per_Capita_headroom",
                                    "Cost_for_Debt_and_Liabilities", "Cost_for_Debt_and_Liabilities_headroom"), digits = 4) %>%
        DT::formatPercentage(columns = c("Cost_for_Debt_and_Liabilities_headroom_pct", "Net_Direct_Debt_Per_Capita_headroom_pct"), digits = 4)
    })
    
    output$headroom_us_map_npl <- renderPlot({  
      plot.new()  
      text(x = 0.5, y = 0.5, labels = "Reserves Headroom is not calculated as it is a qualitative metric for States.", cex = 1.5)  
    })
    
    # output$headroom_us_map_npl <- renderPlot({
    #   df <- headroom_data()
    #   #browser()
    #   if (nrow(df) == 0) {
    #     return(ggplot() + 
    #              annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
    #              theme_void())
    #   }
    #   
    #   # Check for required columns
    #   if (!"State" %in% names(df) || !"Budget-based_reserve_as_%_Annual_Revenues_headroom_category" %in% names(df)) {
    #     return(ggplot() + 
    #              annotate("text", x = 0, y = 0, 
    #                       label = "Required columns not found\n(State and Budget-based_reserve_as_%_Annual_Revenues_headroom_category)", 
    #                       size = 5) +
    #              theme_void())
    #   }
    #   
    #   # Prepare data for mapping
    #   # Extract state information and category
    #   category_order <- c("High", "Moderate", "Low", "At the lowest level")
    #   map_data <- df %>%
    #     select(state_raw = State, category = `Budget-based_reserve_as_%_Annual_Revenues_headroom_category`) %>%
    #     mutate(
    #       state_raw = trimws(as.character(state_raw)),
    #       category = factor(trimws(category), levels = category_order)
    #     ) %>%
    #     filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
    #   
    #   if (nrow(map_data) == 0) {
    #     return(ggplot() + 
    #              annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
    #              theme_void())
    #   }
    #   
    #   # Try to extract state names - handle cases like "State of California" or just "California"
    #   map_data <- map_data %>%
    #     mutate(
    #       state = case_when(
    #         # If it contains "State of", extract the state name after it
    #         grepl("State of", state_raw, ignore.case = TRUE) ~ 
    #           trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
    #         # Otherwise use as is
    #         TRUE ~ state_raw
    #       )
    #     )
    #   
    #   # Create US map with color-coded categories
    #   tryCatch({
    #     # Use plot_usmap - it will automatically match state names
    #     category_order <- c("High", "Moderate", "Low", "At the lowest level")
    #     p1 <- plot_usmap(data = map_data, values = "category", regions = "states", color = "black", labels = TRUE) +
    #       scale_fill_discrete(name = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category") +
    #       theme(
    #         legend.position = "right",
    #         legend.text = element_text(size = 10),
    #         legend.title = element_text(size = 12, face = "bold")
    #       ) +
    #       labs(title = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category by State") + scale_fill_manual(
    #         values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
    #     
    #     return(p1)
    #   }, error = function(e) {
    #     # If plot_usmap fails, show error message with data preview
    #     state_sample <- paste(head(map_data$state, 3), collapse = ", ")
    #     ggplot() + 
    #       annotate("text", x = 0, y = 0, 
    #                label = paste0("Error creating map.\nSample states: ", state_sample, 
    #                               "\nEnsure state names match US state names or abbreviations."), 
    #                size = 4) +
    #       theme_void()
    #   })
    #   
    #   
    # })
    
    output$headroom_us_map_nddpc <- renderPlot({
      df <- headroom_data()
      #browser()
      if (nrow(df) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                 theme_void())
      }
      
      # Check for required columns
      if (!"State" %in% names(df) || !"Net_Direct_Debt_Per_Capita_headroom_category" %in% names(df)) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, 
                          label = "Required columns not found\n(State and Net_Direct_Debt_Per_Capita_headroom_category)", 
                          size = 5) +
                 theme_void())
      }
      
      # Prepare data for mapping
      # Extract state information and category
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      map_data <- df %>%
        select(state_raw = State, category = `Net_Direct_Debt_Per_Capita_headroom_category`) %>%
        mutate(
          state_raw = trimws(as.character(state_raw)),
          category = factor(trimws(category), levels = category_order)
        ) %>%
        filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
      
      if (nrow(map_data) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                 theme_void())
      }
      
      # Try to extract state names - handle cases like "State of California" or just "California"
      map_data <- map_data %>%
        mutate(
          state = case_when(
            # If it contains "State of", extract the state name after it
            grepl("State of", state_raw, ignore.case = TRUE) ~ 
              trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
            # Otherwise use as is
            TRUE ~ state_raw
          )
        )
      
      
      # Create US map with color-coded categories
      tryCatch({
        # Use plot_usmap - it will automatically match state names
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        p2 <- plot_usmap(data = map_data, values = "category", regions = "states", color = "black", labels = TRUE) +
          scale_fill_discrete(name = "Net_Direct_Debt_Per_Capita_headroom_category") +
          theme(
            legend.position = "right",
            legend.text = element_text(size = 10),
            legend.title = element_text(size = 12, face = "bold")
          ) +
          labs(title = "Net_Direct_Debt_Per_Capita_headroom_category by State") + scale_fill_manual(
            values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
        
        return(p2)
      }, error = function(e) {
        # If plot_usmap fails, show error message with data preview
        state_sample <- paste(head(map_data$state, 3), collapse = ", ")
        ggplot() + 
          annotate("text", x = 0, y = 0, 
                   label = paste0("Error creating map.\nSample states: ", state_sample, 
                                  "\nEnsure state names match US state names or abbreviations."), 
                   size = 4) +
          theme_void()
      })
      
    })
    
    output$headroom_us_map_cdl <- renderPlot({
      df <- headroom_data()
      #browser()
      if (nrow(df) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                 theme_void())
      }
      
      # Check for required columns
      if (!"State" %in% names(df) || !"Cost_for_Debt_and_Liabilities_headroom_category" %in% names(df)) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, 
                          label = "Required columns not found\n(State and Cost_for_Debt_and_Liabilities_headroom_category)", 
                          size = 5) +
                 theme_void())
      }
      
      # Prepare data for mapping
      # Extract state information and category
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      map_data <- df %>%
        select(state_raw = State, category = `Cost_for_Debt_and_Liabilities_headroom_category`) %>%
        mutate(
          state_raw = trimws(as.character(state_raw)),
          category = factor(trimws(category), levels = category_order)
        ) %>%
        filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
      
      if (nrow(map_data) == 0) {
        return(ggplot() + 
                 annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                 theme_void())
      }
      
      # Try to extract state names - handle cases like "State of California" or just "California"
      map_data <- map_data %>%
        mutate(
          state = case_when(
            # If it contains "State of", extract the state name after it
            grepl("State of", state_raw, ignore.case = TRUE) ~ 
              trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
            # Otherwise use as is
            TRUE ~ state_raw
          )
        )
      
      # Create US map with color-coded categories
      tryCatch({
        # Use plot_usmap - it will automatically match state names
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        p3 <- plot_usmap(data = map_data, values = "category", regions = "states", color = "black", labels = TRUE) +
          scale_fill_discrete(name = "Cost_for_Debt_and_Liabilities_headroom_category") +
          theme(
            legend.position = "right",
            legend.text = element_text(size = 10),
            legend.title = element_text(size = 12, face = "bold")
          ) +
          labs(title = "Cost_for_Debt_and_Liabilities_headroom_category by State") + scale_fill_manual(
            values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
        
        return(p3)
      }, error = function(e) {
        # If plot_usmap fails, show error message with data preview
        state_sample <- paste(head(map_data$state, 3), collapse = ", ")
        ggplot() + 
          annotate("text", x = 0, y = 0, 
                   label = paste0("Error creating map.\nSample states: ", state_sample, 
                                  "\nEnsure state names match US state names or abbreviations."), 
                   size = 4) +
          theme_void()
      })
      
      
    })
    
    # output$headroom_graph_npl <- renderPlot({
    #   category_order <- c("High", "Moderate", "Low", "At the lowest level")
    #   ggplot(headroom_data(), aes(x =  factor(`Budget-based_reserve_as_%_Annual_Revenues_headroom_category`, levels = category_order))) +
    #     geom_bar(fill = "steelblue") +
    #     geom_text(
    #       stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
    #     labs(
    #       title = "",
    #       x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
    #       y = "Count"
    #     ) +
    #     theme_minimal(base_size = 10) +
    #     theme(axis.title.x = element_text(margin = margin(t = 16)),
    #           axis.text.x = element_text(margin = margin(t = 8)))    
    # }, res = 192
    # )
    
    output$headroom_graph_npl <- renderPlot({  
      plot.new()  
      text(x = 0.5, y = 0.5, labels = "Reserves Headroom is not calculated as it is a qualitative metric for States.", cex = 1.5)  
    })
    
    output$headroom_graph_nddpc <- renderPlot({  
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      ggplot(headroom_data(), aes(x =  factor(`Net_Direct_Debt_Per_Capita_headroom_category`, levels = category_order))) +
        geom_bar(fill = "steelblue") + geom_text(
          stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
        labs(
          title = "",
          x = " Net_Direct_Debt_Per_Capita_headroom_category",
          y = "Count"
        ) +
        theme_minimal(base_size = 10) +
        theme(axis.title.x = element_text(margin = margin(t = 16)),
              axis.text.x = element_text(margin = margin(t = 8)))    
    }, res = 192
    )
    
    output$headroom_graph_cdl <- renderPlot({
      category_order <- c("High", "Moderate", "Low", "At the lowest level")
      ggplot(headroom_data(), aes(x =  factor(`Cost_for_Debt_and_Liabilities_headroom_category`, levels = category_order))) + 
        geom_bar(fill = "steelblue") +
        geom_text(
          stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
        labs(
          title = "",
          x = " Cost_for_Debt_and_Liabilities_headroom_category",
          y = "Count"
        ) +
        theme_minimal(base_size = 10) +
        theme(axis.title.x = element_text(margin = margin(t = 16)),
              axis.text.x = element_text(margin = margin(t = 8)))    
    }, res = 192
    )
    
    
    }
    
    else if (input$portfolio_selector == "Municipalities") {
      headroom_data <<- reactive({
        headroom_dt <- tryCatch({
          #read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Municipalities")
          #data_to_use()
          master_report
        }, error = function(e) {
          data.frame(
            `Entity_Name` = character(),
            State = character(),
            `Budget-based_reserve_as_%_Annual_Revenues_headroom_category` = character(),
            `Net_Direct_Debt_Per_Capita_headroom_category` = character(),
            `Cost_for_Debt_and_Liabilities_headroom_category` = character(),
            FIPS = character(),
            stringsAsFactors = FALSE
          )
        })
        
        headroom_dt$State <- as.factor(headroom_dt$State)
        headroom_dt$Analyst <- as.factor(headroom_dt$Analyst)
        headroom_dt$`Entity_Name` <- as.factor(headroom_dt$`Entity_Name`)
        
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category')
        headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category' <- as.factor(headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Cost_for_Debt_and_Liabilities_Score' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Reserves_Initial_Score' <- as.factor(headroom_dt$'Reserves_Initial_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct')
        
        headroom_dt
      })
      
      state_choices <- sort(unique(data_to_use()$State))
      
      #updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = NULL)
      updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = state_choices)
      
      output$headroom_data <- DT::renderDataTable({
        DT::datatable(
          headroom_data() %>% select( -'Portfolio',-'SPID'),
          filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
          options = list(
            dom = 'Blfrtip',
            buttons = c('copy', 'excel', 'pdf'),
            scrollX = TRUE,
            paging = TRUE,
            scrollY = 400,
            scrollCollapse = TRUE,
            #fixedHeader = TRUE,
            fixedColumns = list(leftColumns = 3, rightColumns = 0),
            lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
            initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
            pageLength = 100)) %>%
          DT::formatRound(columns = c("Net_Direct_Debt_Per_Capita", "Net_Direct_Debt_Per_Capita_headroom", "Budget_based_reserve_as_pct_Annual_Revenues", 
                                    "Cost_for_Debt_and_Liabilities", "Cost_for_Debt_and_Liabilities_headroom", "Budget-based_reserve_as_%_Annual_Revenues_headroom"), digits = 4) %>%
          DT::formatPercentage(columns = c( "Cost_for_Debt_and_Liabilities_headroom_pct", "Budget-based_reserve_as_%_Annual_Revenues_headroom_pct",
                                          "Net_Direct_Debt_Per_Capita_headroom_pct" ), digits = 4)
      })
      
      output$headroom_us_map_npl <- renderPlot({  
        plot.new()  
        text(x = 0.5, y = 0.5, labels = "US Mapping for Municipalities is currently not supported in the tool.", cex = 1.5)  
      })
      
      output$headroom_us_map_nddpc <- renderPlot({  
        plot.new()  
        text(x = 0.5, y = 0.5, labels = "US Mapping for Municipalities is currently not supported in the tool.", cex = 1.5)  
      })
      
      output$headroom_us_map_cdl <- renderPlot({  
        plot.new()  
        text(x = 0.5, y = 0.5, labels = "US Mapping for Municipalities is currently not supported in the tool.", cex = 1.5)  
      })
      
      output$headroom_graph_npl <- renderPlot({
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Budget-based_reserve_as_%_Annual_Revenues_headroom_category`, levels = category_order))) +
          geom_bar(fill = "steelblue") +
          geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      output$headroom_graph_nddpc <- renderPlot({  
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Net_Direct_Debt_Per_Capita_headroom_category`, levels = category_order))) +
          geom_bar(fill = "steelblue") + geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Net_Direct_Debt_Per_Capita_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      output$headroom_graph_cdl <- renderPlot({
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Cost_for_Debt_and_Liabilities_headroom_category`, levels = category_order))) + 
          geom_bar(fill = "steelblue") +
          geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Cost_for_Debt_and_Liabilities_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
    }
      
      
    else{
      headroom_data <<- reactive({
        headroom_dt <- tryCatch({
          #read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Counties")
          #data_to_use()
          master_report
        }, error = function(e) {
          data.frame(
            `Entity_Name` = character(),
            State = character(),
            `Budget-based_reserve_as_%_Annual_Revenues_headroom_category` = character(),
            `Net_Direct_Debt_Per_Capita_headroom_category` = character(),
            `Cost_for_Debt_and_Liabilities_headroom_category` = character(),
            FIPS = character(),
            stringsAsFactors = FALSE
          )
        })
        
        headroom_dt$State <- as.factor(headroom_dt$State)
        headroom_dt$Analyst <- as.factor(headroom_dt$Analyst)
        headroom_dt$`Entity_Name` <- as.factor(headroom_dt$`Entity_Name`)
        
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category')
        headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category' <- as.factor(headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Cost_for_Debt_and_Liabilities_Score' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Reserves_Initial_Score' <- as.factor(headroom_dt$'Reserves_Initial_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct')
        
        headroom_dt
      })
      
      state_choices <- sort(unique(data_to_use()$State))
      
      #updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = NULL)
      updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = state_choices)

      output$headroom_data <- DT::renderDataTable({
        DT::datatable( 
          headroom_data() %>% select( -'Portfolio',-'SPID'),
          filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
          options = list(
            dom = 'Blfrtip',
            buttons = c('copy', 'excel', 'pdf'),
            scrollX = TRUE,
            paging = TRUE,
            scrollY = 400,   
            scrollCollapse = TRUE,     
            #fixedHeader = TRUE,
            fixedColumns = list(leftColumns = 3, rightColumns = 0),
            lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
            initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
            pageLength = 100)) %>% 
          DT::formatRound(columns = c("Net_Direct_Debt_Per_Capita", "Net_Direct_Debt_Per_Capita_headroom", "Budget_based_reserve_as_pct_Annual_Revenues", 
                                    "Cost_for_Debt_and_Liabilities", "Cost_for_Debt_and_Liabilities_headroom", "Budget-based_reserve_as_%_Annual_Revenues_headroom"), digits = 4) %>%
          DT::formatPercentage(columns = c( "Cost_for_Debt_and_Liabilities_headroom_pct", "Budget-based_reserve_as_%_Annual_Revenues_headroom_pct",
                                          "Net_Direct_Debt_Per_Capita_headroom_pct" ), digits = 4)
      })
      output$headroom_us_map_npl <- renderPlot({
        df <- headroom_data()
        if (nrow(df) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                   theme_void())
        }
        
        # Check for required columns
        if (!"FIPS" %in% names(df) || !"Budget-based_reserve_as_%_Annual_Revenues_headroom_category" %in% names(df)) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, 
                            label = "Required columns not found\n(FIPS and Budget-based_reserve_as_%_Annual_Revenues_headroom_category)", 
                            size = 5) +
                   theme_void())
        }
        
        # Prepare data for mapping
        # Extract state information and category
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        map_data <- df %>%
          select(fips = `FIPS`, state_raw = State, category = `Budget-based_reserve_as_%_Annual_Revenues_headroom_category`) %>%
          mutate(
            fips = as.character(fips),
            state_raw = trimws(as.character(state_raw)),
            category = factor(trimws(category), levels = category_order)
          ) %>%
          filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
        
        if (nrow(map_data) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                   theme_void())
        }
        
        # Try to extract state names - handle cases like "State of California" or just "California"
        map_data <- map_data %>%
          mutate(
            state = case_when(
              # If it contains "State of", extract the state name after it
              grepl("State of", state_raw, ignore.case = TRUE) ~ 
                trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
              # Otherwise use as is
              TRUE ~ state_raw
            )
          )
        
        
        county_data <- usmap::countypop %>% select(fips)  %>%  left_join(map_data, by = 'fips')
        
        # Create US map with color-coded categories
        tryCatch({
          # Use plot_usmap - it will automatically match state names
          p1 <- plot_usmap(data = map_data, values = "category", regions = "counties", color = "black") +
            scale_fill_discrete(name = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category") +
            theme(
              legend.position = "right",
              legend.text = element_text(size = 10),
              legend.title = element_text(size = 12, face = "bold")
            ) +
            labs(title = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category by County") + scale_fill_manual(
              values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
          
          return(p1)
        }, error = function(e) {
          # If plot_usmap fails, show error message with data preview
          state_sample <- paste(head(map_data$state, 3), collapse = ", ")
          ggplot() + 
            annotate("text", x = 0, y = 0, 
                     label = paste0("Error creating map.\nSample states: ", state_sample, 
                                    "\nEnsure state names match US state names or abbreviations."), 
                     size = 4) +
            theme_void()
        })
        
        
      })
      
      output$headroom_us_map_nddpc <- renderPlot({
        df <- headroom_data()
        if (nrow(df) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                   theme_void())
        }
        
        # Check for required columns
        if (!"FIPS" %in% names(df) || !"Net_Direct_Debt_Per_Capita_headroom_category" %in% names(df)) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, 
                            label = "Required columns not found\n(FIPS and Net_Direct_Debt_Per_Capita_headroom_category)", 
                            size = 5) +
                   theme_void())
        }
        
        # Prepare data for mapping
        # Extract state information and category
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        map_data <- df %>%
          select(fips = `FIPS`, state_raw = State, category = `Net_Direct_Debt_Per_Capita_headroom_category`) %>%
          mutate(
            fips = as.character(fips),
            state_raw = trimws(as.character(state_raw)),
            category = factor(trimws(category), levels = category_order)
          ) %>%
          filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
        
        if (nrow(map_data) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                   theme_void())
        }
        
        # Try to extract state names - handle cases like "State of California" or just "California"
        map_data <- map_data %>%
          mutate(
            state = case_when(
              # If it contains "State of", extract the state name after it
              grepl("State of", state_raw, ignore.case = TRUE) ~ 
                trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
              # Otherwise use as is
              TRUE ~ state_raw
            )
          )
        
        
        county_data <- usmap::countypop %>% select(fips)  %>%  left_join(map_data, by = 'fips')
        
        # Create US map with color-coded categories
        tryCatch({
          # Use plot_usmap - it will automatically match state names
          category_order <- c("High", "Moderate", "Low", "At the lowest level")
          p1 <- plot_usmap(data = map_data, values = "category", regions = "counties", color = "black") +
            scale_fill_discrete(name = "Net_Direct_Debt_Per_Capita_headroom_category") +
            theme(
              legend.position = "right",
              legend.text = element_text(size = 10),
              legend.title = element_text(size = 12, face = "bold")
            ) +
            labs(title = "Net_Direct_Debt_Per_Capita_headroom_category by County") + scale_fill_manual(
              values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
          
          return(p1)
        }, error = function(e) {
          # If plot_usmap fails, show error message with data preview
          state_sample <- paste(head(map_data$state, 3), collapse = ", ")
          ggplot() + 
            annotate("text", x = 0, y = 0, 
                     label = paste0("Error creating map.\nSample states: ", state_sample, 
                                    "\nEnsure state names match US state names or abbreviations."), 
                     size = 4) +
            theme_void()
        })
        
        
      })
      
      output$headroom_us_map_cdl <- renderPlot({
        df <- headroom_data()
        if (nrow(df) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                   theme_void())
        }
        
        # Check for required columns
        if (!"FIPS" %in% names(df) || !"Cost_for_Debt_and_Liabilities_headroom_category" %in% names(df)) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, 
                            label = "Required columns not found\n(FIPS and Cost_for_Debt_and_Liabilities_headroom_category)", 
                            size = 5) +
                   theme_void())
        }
        
        # Prepare data for mapping
        # Extract state information and category
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        map_data <- df %>%
          select(fips = `FIPS`, state_raw = State, category = `Cost_for_Debt_and_Liabilities_headroom_category`) %>%
          mutate(
            fips = as.character(fips),
            state_raw = trimws(as.character(state_raw)),
            category = factor(trimws(category), levels = category_order)
          ) %>%
          filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
        
        if (nrow(map_data) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                   theme_void())
        }
        
        # Try to extract state names - handle cases like "State of California" or just "California"
        map_data <- map_data %>%
          mutate(
            state = case_when(
              # If it contains "State of", extract the state name after it
              grepl("State of", state_raw, ignore.case = TRUE) ~ 
                trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
              # Otherwise use as is
              TRUE ~ state_raw
            )
          )
        
        
        county_data <- usmap::countypop %>% select(fips)  %>%  left_join(map_data, by = 'fips')
        
        # Create US map with color-coded categories
        tryCatch({
          # Use plot_usmap - it will automatically match state names
          category_order <- c("High", "Moderate", "Low", "At the lowest level")
          p1 <- plot_usmap(data = map_data, values = "category", regions = "counties", color = "black") +
            scale_fill_discrete(name = "Cost_for_Debt_and_Liabilities_headroom_category") +
            theme(
              legend.position = "right",
              legend.text = element_text(size = 10),
              legend.title = element_text(size = 12, face = "bold")
            ) +
            labs(title = "Cost_for_Debt_and_Liabilities_headroom_category by County") + scale_fill_manual(
              values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
          
          return(p1)
        }, error = function(e) {
          # If plot_usmap fails, show error message with data preview
          state_sample <- paste(head(map_data$state, 3), collapse = ", ")
          ggplot() + 
            annotate("text", x = 0, y = 0, 
                     label = paste0("Error creating map.\nSample states: ", state_sample, 
                                    "\nEnsure state names match US state names or abbreviations."), 
                     size = 4) +
            theme_void()
        })
        
        
      })
      
      output$headroom_graph_npl <- renderPlot({
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Budget-based_reserve_as_%_Annual_Revenues_headroom_category`, levels = category_order))) +
          geom_bar(fill = "steelblue") +
          geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      output$headroom_graph_nddpc <- renderPlot({  
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Net_Direct_Debt_Per_Capita_headroom_category`, levels = category_order))) +
          geom_bar(fill = "steelblue") + geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Net_Direct_Debt_Per_Capita_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      output$headroom_graph_cdl <- renderPlot({
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Cost_for_Debt_and_Liabilities_headroom_category`, levels = category_order))) + 
          geom_bar(fill = "steelblue") +
          geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Cost_for_Debt_and_Liabilities_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      
      # output$headroom_us_map_npl <- renderPlot({
      #   ggplot(headroom_data(), aes(x =  `Budget-based_reserve_as_%_Annual_Revenues_headroom_category`)) +
      #     geom_bar(fill = "steelblue") +
      #     labs(
      #       title = "",
      #       x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
      #       y = "Count"
      #     ) +
      #     theme_minimal()
      # })
      # 
      # 
      # output$headroom_us_map_nddpc <- renderPlot({
      #   ggplot(headroom_data(), aes(x =  `Net_Direct_Debt_Per_Capita_headroom_category`)) +
      #     geom_bar(fill = "steelblue") +
      #     labs(
      #       title = "",
      #       x = " Net_Direct_Debt_Per_Capita_headroom_category",
      #       y = "Count"
      #     ) +
      #     theme_minimal()
      # })
      # 
      # output$headroom_us_map_cdl <- renderPlot({
      #   ggplot(headroom_data(), aes(x =  `Cost_for_Debt_and_Liabilities_headroom_category`)) +
      #     geom_bar(fill = "steelblue") +
      #     labs(
      #       title = "",
      #       x = " Cost_for_Debt_and_Liabilities_headroom_category",
      #       y = "Count"
      #     ) +
      #     theme_minimal()
      # })
    }
    
  })
  observeEvent(c(input$geo_filter, input$portfolio_selector), {
    shinybusy::show_modal_progress_line()
    shinybusy::show_modal_spinner(
      spin = "cube-grid",
      color = "firebrick",
      text = "Fetching Headroom Data..."
    )
    # if (input$portfolio_selector == "States") {displayed_data <- read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - States")}
    # else if (input$portfolio_selector == "Municipalities") {displayed_data <- read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Municipalities")}
    # else {displayed_data <- read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Counties")}
    
    if (input$portfolio_selector == "States") {displayed_data <- GO_data_States}
    else if (input$portfolio_selector == "Municipalities") {displayed_data <- GO_data_Munis}
    else {displayed_data <- GO_data_Counties}
    
    #selected_rows <- input$go_risk_data_rows_selected
    
    #req(input$go_risk_data_rows_selected)
    #rows_selection <- input$go_risk_data_rows_all[input$go_risk_data_rows_selected]
    
    #browser()
    
    rows_selection <- input$go_risk_data_rows_selected
    if(is.null(rows_selection)){
      selected_asids <- displayed_data
    }
    else{
      selected_asids <- displayed_data[rows_selection, "ASID", drop = TRUE]
    }
    
    data_to_use <- reactive({
      if(length(rows_selection) == 0) {
        displayed_data
      } else {
        displayed_data[displayed_data$ASID %in% selected_asids, ]
      }
    })
    
    input_data_filtered <- data_to_use()
    #input_data_filtered <- selected_asids
    
    #browser()
    
    # ==============================================================================
    # 3. DEFINE SCENARIOS (USING DIRECT TECHNICAL KEYS)
    # ==============================================================================
    scenarios <- list(
      "Base Case" = list(
        "Net_Direct_Debt_Per_Capita" = 1,
        "Cost_for_Debt_and_Liabilities"         = 1,
        "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
      )
      # ,
      # 
      # "Stress: High Debt & Cost" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1.30,
      #   "Cost_for_Debt_and_Liabilities"         = 1.50,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 1
      # ),
      # 
      # "Stress: Low Reserves" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1,
      #   "Cost_for_Debt_and_Liabilities"         = 1,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.50
      # ),
      # 
      # "Extreme: Systemic Stress" = list(
      #   "Net_Direct_Debt_Per_Capita" = 1.50,
      #   "Cost_for_Debt_and_Liabilities"         = 1.50,
      #   "Budget_based_reserve_as_pct_Annual_Revenues"       = 0.20
      # )
    )
    
    # ==============================================================================
    # 4. EXECUTION ENGINE
    # ==============================================================================
    engine <- risk.resilience.quantifier$new(
      config_path = CONFIG_PATH,
      target_model_name = MODEL_NAME,
      target_subsector = input$portfolio_selector
    )
    
    all_results_list <- list()
    message(paste0("Starting Scenario Analysis for sector: ", input$portfolio_selector))
    
    for (s_name in names(scenarios)) {
      message(paste0("-> Running: ", s_name))
      
      # We treat Base Case the same as others to ensure the pipeline is identical
      # 1. Create a full map (Baseline 1.0 for all metrics in config, then overlay stress)
      full_tech_map <- setNames(rep(1.0, length(engine$metrics_config)),
                                sapply(engine$metrics_config, function(x) x$metric_key))
      
      # 2. Overlay the specific multipliers from the scenario
      for (k in names(scenarios[[s_name]])) {
        full_tech_map[[k]] <- scenarios[[s_name]][[k]]
      }
      
      res <- engine$run_scenario_analysis(
        base_data = input_data_filtered,
        #base_data = selected_asids,
        scenario_map = full_tech_map,
        scenario_name = s_name
      )
      
      all_results_list[[s_name]] <- res
    }
    
    master_report <<- rbindlist(all_results_list)
    setcolorder(master_report, "scenario_label")
    
    # ==============================================================================
    # 5. OUTPUT
    # ==============================================================================
    cat("\n--- MASTER SCENARIO REPORT GEOFILTER & FILTER CREDITS ---\n")
    print(master_report)
    
    # data_to_use <- reactive({
    #   if(length(selected_asids) == 0) {
    #     master_report
    #   } else {
    #     master_report[master_report$ASID %in% selected_asids, ]
    #   }
    # })
    # 
    

    if (input$portfolio_selector == "States") {
      #state_choices <- sort(unique(data_to_use()$State))

      #updateSelectInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = NULL)
      #updateSelectizeInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = state_choices)
      # Headroom Analysis - Read data and render outputs
      headroom_data <- reactive({
        headroom_dt <- tryCatch({
          #read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - States")
          master_report
        }, error = function(e) {
          data.frame(
            State = character(),
            `Budget-based_reserve_as_%_Annual_Revenues_headroom_category` = character(),
            `Net_Direct_Debt_Per_Capita_headroom_category` = character(),
            `Cost_for_Debt_and_Liabilities_headroom_category` = character(),
            stringsAsFactors = FALSE
          )
        })
        headroom_dt$State <- as.factor(headroom_dt$State)
        headroom_dt$Analyst <- as.factor(headroom_dt$Analyst)
        headroom_dt$`Entity_Name` <- as.factor(headroom_dt$`Entity_Name`)
        
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category')
        headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category' <- as.factor(headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Cost_for_Debt_and_Liabilities_Score' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Reserves_Initial_Score' <- as.factor(headroom_dt$'Reserves_Initial_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct')
        
        headroom_dt
      })
      
      #browser()
      
      output$headroom_data <- DT::renderDataTable({
        #browser()
        DT::datatable( 
          headroom_data() %>% select( -'Portfolio',-'SPID', -'Budget-based_reserve_as_%_Annual_Revenues_headroom', -'Budget-based_reserve_as_%_Annual_Revenues_headroom_pct',
                                      -'Budget-based_reserve_as_%_Annual_Revenues_headroom_category', -'Budget-based_reserve_as_%_Annual_Revenues_status'),
          filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
          options = list(
            dom = 'Blfrtip',
            buttons = c('copy', 'excel', 'pdf'),
            scrollX = TRUE,
            paging = TRUE,
            scrollY = 400,   
            scrollCollapse = TRUE,     
            #fixedHeader = TRUE,
            fixedColumns = list(leftColumns = 3, rightColumns = 0),
            lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
            initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
            pageLength = 100)) %>% 
          DT::formatRound(columns = c("Net_Direct_Debt_Per_Capita", "Net_Direct_Debt_Per_Capita_headroom",
                                      "Cost_for_Debt_and_Liabilities", "Cost_for_Debt_and_Liabilities_headroom"), digits = 4) %>%
          DT::formatPercentage(columns = c("Cost_for_Debt_and_Liabilities_headroom_pct", "Net_Direct_Debt_Per_Capita_headroom_pct"), digits = 4)
      })
      
      output$headroom_us_map_npl <- renderPlot({  
        plot.new()  
        text(x = 0.5, y = 0.5, labels = "Reserves Headroom is not calculated as it is a qualitative metric for States.", cex = 1.5)  
      })
      
      # output$headroom_us_map_npl <- renderPlot({
      #   df <- headroom_data()
      #   #browser()
      #   if (nrow(df) == 0) {
      #     return(ggplot() + 
      #              annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
      #              theme_void())
      #   }
      #   
      #   # Check for required columns
      #   if (!"State" %in% names(df) || !"Budget-based_reserve_as_%_Annual_Revenues_headroom_category" %in% names(df)) {
      #     return(ggplot() + 
      #              annotate("text", x = 0, y = 0, 
      #                       label = "Required columns not found\n(State and Budget-based_reserve_as_%_Annual_Revenues_headroom_category)", 
      #                       size = 5) +
      #              theme_void())
      #   }
      #   
      #   # Prepare data for mapping
      #   # Extract state information and category
      #   category_order <- c("High", "Moderate", "Low", "At the lowest level")
      #   map_data <- df %>%
      #     select(state_raw = State, category = `Budget-based_reserve_as_%_Annual_Revenues_headroom_category`) %>%
      #     mutate(
      #       state_raw = trimws(as.character(state_raw)),
      #       category = factor(trimws(category), levels = category_order)
      #     ) %>%
      #     filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
      #   
      #   if (nrow(map_data) == 0) {
      #     return(ggplot() + 
      #              annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
      #              theme_void())
      #   }
      #   
      #   # Try to extract state names - handle cases like "State of California" or just "California"
      #   map_data <- map_data %>%
      #     mutate(
      #       state = case_when(
      #         # If it contains "State of", extract the state name after it
      #         grepl("State of", state_raw, ignore.case = TRUE) ~ 
      #           trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
      #         # Otherwise use as is
      #         TRUE ~ state_raw
      #       )
      #     )
      #   
      #   # Create US map with color-coded categories
      #   tryCatch({
      #     #browser()
      #     # Use plot_usmap - it will automatically match state names
      #     category_order <- c("High", "Moderate", "Low", "At the lowest level")
      #     p1 <- plot_usmap(data = map_data, values = "category", regions = "states", color = "black", include = input$geo_filter, labels = TRUE) +
      #       scale_fill_discrete(name = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category") +
      #       theme(
      #         legend.position = "right",
      #         legend.text = element_text(size = 10),
      #         legend.title = element_text(size = 12, face = "bold")
      #       ) +
      #       labs(title = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category by State") + scale_fill_manual(
      #         values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
      #     
      #     return(p1)
      #   }, error = function(e) {
      #     # If plot_usmap fails, show error message with data preview
      #     state_sample <- paste(head(map_data$state, 3), collapse = ", ")
      #     ggplot() + 
      #       annotate("text", x = 0, y = 0, 
      #                label = paste0("Error creating map.\nSample states: ", state_sample, 
      #                               "\nEnsure state names match US state names or abbreviations."), 
      #                size = 4) +
      #       theme_void()
      #   })
      #   
      #   
      # })
      
      output$headroom_us_map_nddpc <- renderPlot({
        df <- headroom_data()
        #browser()
        if (nrow(df) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                   theme_void())
        }
        
        # Check for required columns
        if (!"State" %in% names(df) || !"Net_Direct_Debt_Per_Capita_headroom_category" %in% names(df)) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, 
                            label = "Required columns not found\n(State and Net_Direct_Debt_Per_Capita_headroom_category)", 
                            size = 5) +
                   theme_void())
        }
        
        # Prepare data for mapping
        # Extract state information and category
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        map_data <- df %>%
          select(state_raw = State, category = `Net_Direct_Debt_Per_Capita_headroom_category`) %>%
          mutate(
            state_raw = trimws(as.character(state_raw)),
            category = factor(trimws(category), levels = category_order)
          ) %>%
          filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
        
        if (nrow(map_data) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                   theme_void())
        }
        
        # Try to extract state names - handle cases like "State of California" or just "California"
        map_data <- map_data %>%
          mutate(
            state = case_when(
              # If it contains "State of", extract the state name after it
              grepl("State of", state_raw, ignore.case = TRUE) ~ 
                trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
              # Otherwise use as is
              TRUE ~ state_raw
            )
          )
        
        
        # Create US map with color-coded categories
        tryCatch({
          # Use plot_usmap - it will automatically match state names
          category_order <- c("High", "Moderate", "Low", "At the lowest level")
          p2 <- plot_usmap(data = map_data, values = "category", regions = "states", color = "black", include = input$geo_filter, labels = TRUE) +
            scale_fill_discrete(name = "Net_Direct_Debt_Per_Capita_headroom_category") +
            theme(
              legend.position = "right",
              legend.text = element_text(size = 10),
              legend.title = element_text(size = 12, face = "bold")
            ) +
            labs(title = "Net_Direct_Debt_Per_Capita_headroom_category by State") + scale_fill_manual(
              values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
          
          return(p2)
        }, error = function(e) {
          # If plot_usmap fails, show error message with data preview
          state_sample <- paste(head(map_data$state, 3), collapse = ", ")
          ggplot() + 
            annotate("text", x = 0, y = 0, 
                     label = paste0("Error creating map.\nSample states: ", state_sample, 
                                    "\nEnsure state names match US state names or abbreviations."), 
                     size = 4) +
            theme_void()
        })
        
      })
      
      output$headroom_us_map_cdl <- renderPlot({
        df <- headroom_data()
        #browser()
        if (nrow(df) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                   theme_void())
        }
        
        # Check for required columns
        if (!"State" %in% names(df) || !"Cost_for_Debt_and_Liabilities_headroom_category" %in% names(df)) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, 
                            label = "Required columns not found\n(State and Cost_for_Debt_and_Liabilities_headroom_category)", 
                            size = 5) +
                   theme_void())
        }
        
        # Prepare data for mapping
        # Extract state information and category
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        map_data <- df %>%
          select(state_raw = State, category = `Cost_for_Debt_and_Liabilities_headroom_category`) %>%
          mutate(
            state_raw = trimws(as.character(state_raw)),
            category = factor(trimws(category), levels = category_order)
          ) %>%
          filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
        
        if (nrow(map_data) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                   theme_void())
        }
        
        # Try to extract state names - handle cases like "State of California" or just "California"
        map_data <- map_data %>%
          mutate(
            state = case_when(
              # If it contains "State of", extract the state name after it
              grepl("State of", state_raw, ignore.case = TRUE) ~ 
                trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
              # Otherwise use as is
              TRUE ~ state_raw
            )
          )
        
        # Create US map with color-coded categories
        tryCatch({
          # Use plot_usmap - it will automatically match state names
          category_order <- c("High", "Moderate", "Low", "At the lowest level")
          p3 <- plot_usmap(data = map_data, values = "category", regions = "states", color = "black", include = input$geo_filter, labels = TRUE) +
            scale_fill_discrete(name = "Cost_for_Debt_and_Liabilities_headroom_category") +
            theme(
              legend.position = "right",
              legend.text = element_text(size = 10),
              legend.title = element_text(size = 12, face = "bold")
            ) +
            labs(title = "Cost_for_Debt_and_Liabilities_headroom_category by State") + scale_fill_manual(
              values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
          
          return(p3)
        }, error = function(e) {
          # If plot_usmap fails, show error message with data preview
          state_sample <- paste(head(map_data$state, 3), collapse = ", ")
          ggplot() + 
            annotate("text", x = 0, y = 0, 
                     label = paste0("Error creating map.\nSample states: ", state_sample, 
                                    "\nEnsure state names match US state names or abbreviations."), 
                     size = 4) +
            theme_void()
        })
        
        
      })
      
      output$headroom_graph_npl <- renderPlot({  
        plot.new()  
        text(x = 0.5, y = 0.5, labels = "Reserves Headroom is not calculated as it is a qualitative metric for States.", cex = 1.5)  
      })
      
      # output$headroom_graph_npl <- renderPlot({
      #   category_order <- c("High", "Moderate", "Low", "At the lowest level")
      #   ggplot(headroom_data(), aes(x =  factor(`Budget-based_reserve_as_%_Annual_Revenues_headroom_category`, levels = category_order))) +
      #     geom_bar(fill = "steelblue") + 
      #     geom_text(
      #       stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
      #     labs(
      #       title = "",
      #       x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
      #       y = "Count"
      #     ) +
      #     theme_minimal(base_size = 10) +
      #     theme(axis.title.x = element_text(margin = margin(t = 16)),
      #           axis.text.x = element_text(margin = margin(t = 8)))    
      # }, res = 192
      # )
      
      output$headroom_graph_nddpc <- renderPlot({  
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Net_Direct_Debt_Per_Capita_headroom_category`, levels = category_order))) +
          geom_bar(fill = "steelblue") + geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Net_Direct_Debt_Per_Capita_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      output$headroom_graph_cdl <- renderPlot({
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Cost_for_Debt_and_Liabilities_headroom_category`, levels = category_order))) + 
          geom_bar(fill = "steelblue") + 
          geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Cost_for_Debt_and_Liabilities_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      
    }
    
    else if (input$portfolio_selector == "Municipalities") {
      #state_choices <- sort(unique(data_to_use()$State))
      #choices_data <- req(state_choices)
      
      #updateSelectInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = NULL)
      #updateSelectInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = state_choices)
      
      headroom_data <- reactive({
        headroom_dt <- tryCatch({
          #read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Municipalities")
          master_report
        }, error = function(e) {
          data.frame(
            `Entity_Name` = character(),
            State = character(),
            `Budget-based_reserve_as_%_Annual_Revenues_headroom_category` = character(),
            `Net_Direct_Debt_Per_Capita_headroom_category` = character(),
            `Cost_for_Debt_and_Liabilities_headroom_category` = character(),
            FIPS = character(),
            stringsAsFactors = FALSE
          )
        })
        
        headroom_dt$State <- as.factor(headroom_dt$State)
        headroom_dt$Analyst <- as.factor(headroom_dt$Analyst)
        headroom_dt$`Entity_Name` <- as.factor(headroom_dt$`Entity_Name`)
        
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category')
        headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category' <- as.factor(headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Cost_for_Debt_and_Liabilities_Score' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Reserves_Initial_Score' <- as.factor(headroom_dt$'Reserves_Initial_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct')
        
        headroom_dt
      })
      
      output$headroom_data <- DT::renderDataTable({
        DT::datatable( 
          headroom_data() %>% select( -'Portfolio',-'SPID'),
          filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
          options = list(
            dom = 'Blfrtip',
            buttons = c('copy', 'excel', 'pdf'),
            scrollX = TRUE,
            paging = TRUE,
            scrollY = 400,   
            scrollCollapse = TRUE,     
            #fixedHeader = TRUE,
            fixedColumns = list(leftColumns = 3, rightColumns = 0),
            lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
            initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
            pageLength = 100)) %>% 
          DT::formatRound(columns = c("Net_Direct_Debt_Per_Capita", "Net_Direct_Debt_Per_Capita_headroom", "Budget_based_reserve_as_pct_Annual_Revenues", 
                                    "Cost_for_Debt_and_Liabilities", "Cost_for_Debt_and_Liabilities_headroom", "Budget-based_reserve_as_%_Annual_Revenues_headroom"), digits = 4) %>%
          DT::formatPercentage(columns = c( "Cost_for_Debt_and_Liabilities_headroom_pct", "Budget-based_reserve_as_%_Annual_Revenues_headroom_pct",
                                          "Net_Direct_Debt_Per_Capita_headroom_pct" ), digits = 4)
      })
      
      output$headroom_us_map_npl <- renderPlot({  
        plot.new()  
        text(x = 0.5, y = 0.5, labels = "US Mapping for Municipalities is currently not supported in the tool.", cex = 1.5)  
      })
      
      output$headroom_us_map_nddpc <- renderPlot({  
        plot.new()  
        text(x = 0.5, y = 0.5, labels = "US Mapping for Municipalities is currently not supported in the tool.", cex = 1.5)  
      })
      
      output$headroom_us_map_cdl <- renderPlot({  
        plot.new()  
        text(x = 0.5, y = 0.5, labels = "US Mapping for Municipalities is currently not supported in the tool.", cex = 1.5)  
      })
      
      output$headroom_graph_npl <- renderPlot({
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Budget-based_reserve_as_%_Annual_Revenues_headroom_category`, levels = category_order))) +
          geom_bar(fill = "steelblue") + 
          geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      output$headroom_graph_nddpc <- renderPlot({  
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Net_Direct_Debt_Per_Capita_headroom_category`, levels = category_order))) +
          geom_bar(fill = "steelblue") + geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Net_Direct_Debt_Per_Capita_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      output$headroom_graph_cdl <- renderPlot({
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Cost_for_Debt_and_Liabilities_headroom_category`, levels = category_order))) + 
          geom_bar(fill = "steelblue") + 
          geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Cost_for_Debt_and_Liabilities_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
    }
    
    else{
      #state_choices <- sort(unique(data_to_use()$State))
      #choices_data <- req(state_choices)
      
      #updateSelectInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = NULL)
      #updateSelectInput(session, "geo_filter", "Geo Filter", choices = state_choices, selected = state_choices)

      headroom_data <- reactive({
        headroom_dt <- tryCatch({
          #read_xlsx("./GO/GO_Headroom_Full_dataset.xlsx", sheet = "Headroom - Counties")
          master_report
        }, error = function(e) {
          data.frame(
            `Entity_Name` = character(),
            State = character(),
            `Budget-based_reserve_as_%_Annual_Revenues_headroom_category` = character(),
            `Net_Direct_Debt_Per_Capita_headroom_category` = character(),
            `Cost_for_Debt_and_Liabilities_headroom_category` = character(),
            FIPS = character(),
            stringsAsFactors = FALSE
          )
        })
        
        headroom_dt$State <- as.factor(headroom_dt$State)
        headroom_dt$Analyst <- as.factor(headroom_dt$Analyst)
        headroom_dt$`Entity_Name` <- as.factor(headroom_dt$`Entity_Name`)
        
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_category')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_category')
        headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category' <- as.factor(headroom_dt$'Budget-based_reserve_as_%_Annual_Revenues_headroom_category')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Cost_for_Debt_and_Liabilities_Score' <- as.factor(headroom_dt$'Cost_for_Debt_and_Liabilities_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_Score' <- as.factor(headroom_dt$'Net_Direct_Debt_Per_Capita_Score')
        headroom_dt$'Reserves_Initial_Score' <- as.factor(headroom_dt$'Reserves_Initial_Score')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom')
        headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct' <- as.numeric(headroom_dt$'Net_Direct_Debt_Per_Capita_headroom_pct')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom')
        headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct' <- as.numeric(headroom_dt$'Cost_for_Debt_and_Liabilities_headroom_pct')
        
        headroom_dt
      })
      
      output$headroom_data <- DT::renderDataTable({
        DT::datatable( 
          headroom_data() %>% select( -'Portfolio',-'SPID'),
          filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
          options = list(
            dom = 'Blfrtip',
            buttons = c('copy', 'excel', 'pdf'),
            scrollX = TRUE,
            paging = TRUE,
            scrollY = 400,   
            scrollCollapse = TRUE,     
            #fixedHeader = TRUE,
            fixedColumns = list(leftColumns = 3, rightColumns = 0),
            lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
            initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
            pageLength = 100)) %>% 
          DT::formatRound(columns = c("Net_Direct_Debt_Per_Capita", "Net_Direct_Debt_Per_Capita_headroom", "Budget_based_reserve_as_pct_Annual_Revenues", 
                                    "Cost_for_Debt_and_Liabilities", "Cost_for_Debt_and_Liabilities_headroom", "Budget-based_reserve_as_%_Annual_Revenues_headroom"), digits = 4) %>%
          DT::formatPercentage(columns = c( "Cost_for_Debt_and_Liabilities_headroom_pct", "Budget-based_reserve_as_%_Annual_Revenues_headroom_pct",
                                          "Net_Direct_Debt_Per_Capita_headroom_pct" ), digits = 4)
      })
      
      output$headroom_us_map_npl <- renderPlot({
        df <- headroom_data()
        if (nrow(df) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                   theme_void())
        }
        
        # Check for required columns
        if (!"FIPS" %in% names(df) || !"Budget-based_reserve_as_%_Annual_Revenues_headroom_category" %in% names(df)) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, 
                            label = "Required columns not found\n(FIPS and Budget-based_reserve_as_%_Annual_Revenues_headroom_category)", 
                            size = 5) +
                   theme_void())
        }
        
        # Prepare data for mapping
        # Extract state information and category
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        map_data <- df %>%
          select(fips = `FIPS`, state_raw = State, category = `Budget-based_reserve_as_%_Annual_Revenues_headroom_category`) %>%
          mutate(
            fips = as.character(fips),
            state_raw = trimws(as.character(state_raw)),
            category = factor(trimws(category), levels = category_order)
          ) %>%
          filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
        
        if (nrow(map_data) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                   theme_void())
        }
        
        # Try to extract state names - handle cases like "State of California" or just "California"
        map_data <- map_data %>%
          mutate(
            state = case_when(
              # If it contains "State of", extract the state name after it
              grepl("State of", state_raw, ignore.case = TRUE) ~ 
                trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
              # Otherwise use as is
              TRUE ~ state_raw
            )
          )
        
        
        county_data <- usmap::countypop %>% select(fips)  %>%  left_join(map_data, by = 'fips')
        
        # Create US map with color-coded categories
        tryCatch({
          # Use plot_usmap - it will automatically match state names
          p1 <- plot_usmap(data = map_data, values = "category", regions = "counties", color = "black", include = input$geo_filter) +
            scale_fill_discrete(name = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category") +
            theme(
              legend.position = "right",
              legend.text = element_text(size = 10),
              legend.title = element_text(size = 12, face = "bold")
            ) +
            labs(title = "Budget-based_reserve_as_%_Annual_Revenues_headroom_category by County") + scale_fill_manual(
              values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
          
          return(p1)
        }, error = function(e) {
          # If plot_usmap fails, show error message with data preview
          state_sample <- paste(head(map_data$state, 3), collapse = ", ")
          ggplot() + 
            annotate("text", x = 0, y = 0, 
                     label = paste0("Error creating map.\nSample states: ", state_sample, 
                                    "\nEnsure state names match US state names or abbreviations."), 
                     size = 4) +
            theme_void()
        })
        
        
      })
      
      output$headroom_us_map_nddpc <- renderPlot({
        df <- headroom_data()
        if (nrow(df) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                   theme_void())
        }
        
        # Check for required columns
        if (!"FIPS" %in% names(df) || !"Net_Direct_Debt_Per_Capita_headroom_category" %in% names(df)) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, 
                            label = "Required columns not found\n(FIPS and Net_Direct_Debt_Per_Capita_headroom_category)", 
                            size = 5) +
                   theme_void())
        }
        
        # Prepare data for mapping
        # Extract state information and category
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        map_data <- df %>%
          select(fips = `FIPS`, state_raw = State, category = `Net_Direct_Debt_Per_Capita_headroom_category`) %>%
          mutate(
            fips = as.character(fips),
            state_raw = trimws(as.character(state_raw)),
            category = factor(trimws(category), levels = category_order)
          ) %>%
          filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
        
        if (nrow(map_data) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                   theme_void())
        }
        
        # Try to extract state names - handle cases like "State of California" or just "California"
        map_data <- map_data %>%
          mutate(
            state = case_when(
              # If it contains "State of", extract the state name after it
              grepl("State of", state_raw, ignore.case = TRUE) ~ 
                trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
              # Otherwise use as is
              TRUE ~ state_raw
            )
          )
        
        
        county_data <- usmap::countypop %>% select(fips)  %>%  left_join(map_data, by = 'fips')
        
        # Create US map with color-coded categories
        tryCatch({
          # Use plot_usmap - it will automatically match state names
          category_order <- c("High", "Moderate", "Low", "At the lowest level")
          p1 <- plot_usmap(data = map_data, values = "category", regions = "counties", color = "black", include = input$geo_filter) +
            scale_fill_discrete(name = "Net_Direct_Debt_Per_Capita_headroom_category") +
            theme(
              legend.position = "right",
              legend.text = element_text(size = 10),
              legend.title = element_text(size = 12, face = "bold")
            ) +
            labs(title = "Net_Direct_Debt_Per_Capita_headroom_category by County") + scale_fill_manual(
              values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
          
          return(p1)
        }, error = function(e) {
          # If plot_usmap fails, show error message with data preview
          state_sample <- paste(head(map_data$state, 3), collapse = ", ")
          ggplot() + 
            annotate("text", x = 0, y = 0, 
                     label = paste0("Error creating map.\nSample states: ", state_sample, 
                                    "\nEnsure state names match US state names or abbreviations."), 
                     size = 4) +
            theme_void()
        })
        
        
      })
      
      output$headroom_us_map_cdl <- renderPlot({
        df <- headroom_data()
        if (nrow(df) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No data available", size = 6) +
                   theme_void())
        }
        
        # Check for required columns
        if (!"FIPS" %in% names(df) || !"Cost_for_Debt_and_Liabilities_headroom_category" %in% names(df)) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, 
                            label = "Required columns not found\n(FIPS and Cost_for_Debt_and_Liabilities_headroom_category)", 
                            size = 5) +
                   theme_void())
        }
        
        # Prepare data for mapping
        # Extract state information and category
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        map_data <- df %>%
          select(fips = `FIPS`, state_raw = State, category = `Cost_for_Debt_and_Liabilities_headroom_category`) %>%
          mutate(
            fips = as.character(fips),
            state_raw = trimws(as.character(state_raw)),
            category = factor(trimws(category), levels = category_order)
          ) %>%
          filter(!is.na(category) & category != "" & !is.na(state_raw) & state_raw != "")
        
        if (nrow(map_data) == 0) {
          return(ggplot() + 
                   annotate("text", x = 0, y = 0, label = "No valid data for mapping", size = 6) +
                   theme_void())
        }
        
        # Try to extract state names - handle cases like "State of California" or just "California"
        map_data <- map_data %>%
          mutate(
            state = case_when(
              # If it contains "State of", extract the state name after it
              grepl("State of", state_raw, ignore.case = TRUE) ~ 
                trimws(gsub(".*State of\\s+", "", state_raw, ignore.case = TRUE)),
              # Otherwise use as is
              TRUE ~ state_raw
            )
          )
        
        
        county_data <- usmap::countypop %>% select(fips)  %>%  left_join(map_data, by = 'fips')
        
        # Create US map with color-coded categories
        tryCatch({
          # Use plot_usmap - it will automatically match state names
          category_order <- c("High", "Moderate", "Low", "At the lowest level")
          p1 <- plot_usmap(data = map_data, values = "category", regions = "counties", color = "black", include = input$geo_filter) +
            scale_fill_discrete(name = "Cost_for_Debt_and_Liabilities_headroom_category") +
            theme(
              legend.position = "right",
              legend.text = element_text(size = 10),
              legend.title = element_text(size = 12, face = "bold")
            ) +
            labs(title = "Cost_for_Debt_and_Liabilities_headroom_category by County") + scale_fill_manual(
              values = c("High" = "#228B22", "Moderate" = "#FFFF00", "Low" = "#FFC72C", "At the lowest level" = "#C6011F"))
          
          return(p1)
        }, error = function(e) {
          # If plot_usmap fails, show error message with data preview
          state_sample <- paste(head(map_data$state, 3), collapse = ", ")
          ggplot() + 
            annotate("text", x = 0, y = 0, 
                     label = paste0("Error creating map.\nSample states: ", state_sample, 
                                    "\nEnsure state names match US state names or abbreviations."), 
                     size = 4) +
            theme_void()
        })
        
        
      })
      
      output$headroom_graph_npl <- renderPlot({
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Budget-based_reserve_as_%_Annual_Revenues_headroom_category`, levels = category_order))) +
          geom_bar(fill = "steelblue") + 
          geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      output$headroom_graph_nddpc <- renderPlot({  
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Net_Direct_Debt_Per_Capita_headroom_category`, levels = category_order))) +
          geom_bar(fill = "steelblue") + geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Net_Direct_Debt_Per_Capita_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      output$headroom_graph_cdl <- renderPlot({
        category_order <- c("High", "Moderate", "Low", "At the lowest level")
        ggplot(headroom_data(), aes(x =  factor(`Cost_for_Debt_and_Liabilities_headroom_category`, levels = category_order))) + 
          geom_bar(fill = "steelblue") + 
          geom_text(
            stat = "count", aes(label = after_stat(count)), vjust = 1.5, color = "white", size = 3) +
          labs(
            title = "",
            x = " Cost_for_Debt_and_Liabilities_headroom_category",
            y = "Count"
          ) +
          theme_minimal(base_size = 10) +
          theme(axis.title.x = element_text(margin = margin(t = 16)),
                axis.text.x = element_text(margin = margin(t = 8)))    
      }, res = 192
      )
      
      
      # output$headroom_us_map_npl <- renderPlot({
      #   ggplot(headroom_data(), aes(x =  `Budget-based_reserve_as_%_Annual_Revenues_headroom_category`)) +
      #     geom_bar(fill = "steelblue") +
      #     labs(
      #       title = "",
      #       x = " Budget-based_reserve_as_%_Annual_Revenues_headroom_category",
      #       y = "Count"
      #     ) +
      #     theme_minimal()
      # })
      # 
      # 
      # output$headroom_us_map_nddpc <- renderPlot({
      #   ggplot(headroom_data(), aes(x =  `Net_Direct_Debt_Per_Capita_headroom_category`)) +
      #     geom_bar(fill = "steelblue") +
      #     labs(
      #       title = "",
      #       x = " Net_Direct_Debt_Per_Capita_headroom_category",
      #       y = "Count"
      #     ) +
      #     theme_minimal()
      # })
      # 
      # output$headroom_us_map_cdl <- renderPlot({
      #   ggplot(headroom_data(), aes(x =  `Cost_for_Debt_and_Liabilities_headroom_category`)) +
      #     geom_bar(fill = "steelblue") +
      #     labs(
      #       title = "",
      #       x = " Cost_for_Debt_and_Liabilities_headroom_category",
      #       y = "Count"
      #     ) +
      #     theme_minimal()
      # })
    }
    
  })
  
metrics_keys <- c("Net_Direct_Debt_Per_Capita", "Cost_for_Debt_and_Liabilities", "Budget_based_reserve_as_pct_Annual_Revenues")
# REACTIVE STATE
scenario_registry <- reactiveValues(registry = list())
batch_output <- reactiveVal(NULL)
scenario_counter <- reactiveVal(0)
  # --- INITIALIZATION ---
  observe({
    default_mults <- setNames(rep(1.0, length(metrics_keys)), metrics_keys)
    scenario_registry$registry[["base"]] <- list(
      name = "Base Case",
      multipliers = default_mults,
      type = "Base (Protected)"
    )
  })
  
  # --- UI GENERATION ---
  output$builder_sliders <- renderUI({
    lapply(metrics_keys, function(k) {
      sliderInput(paste0("slider_", k),
                  label = gsub("model_inputs.", "", k),
                  min = 0.1, max = 2.0, value = 1.0, step = 0.05,width = "600px")
    })
  })
  
  # --- LOGIC: ADD TO LIBRARY ---
  observeEvent(input$save_scen, {
    if (is.null(input$scen_name) || nchar(trimws(input$scen_name)) == 0) {  
      showNotification(  
        "Scenario Name has not been added. Please add a name.",   
        type = "error",   
        duration = 5  
      )
    }
    req(input$scen_name)
    new_count <- scenario_counter() + 1
    scenario_counter(new_count)
    new_id <- paste0("scen_", new_count)
    new_map <- list()
    for(k in metrics_keys) {
      new_map[[k]] <- input[[paste0("slider_", k)]]
    }
    scenario_registry$registry[[new_id]] <- list(
      name = input$scen_name,
      multipliers = new_map,
      type = "Custom"
    )
    updateTextInput(session, "scen_name", value = "")
    showNotification(paste("Scenario", input$scen_name, "added!"), type = "message")
  })
  
  # --- LOGIC: DISPLAY LIBRARY ---
  output$library_table <- renderDT({
    lib <- scenario_registry$registry
    if(length(lib) == 0) return(datatable(data.frame(Status="No scenarios saved")))
    df <- data.frame(
      ID = names(lib),
      Scenario_Name = sapply(lib, function(x) x$name),
      Type = sapply(lib, function(x) x$type),
      stringsAsFactors = FALSE
    )
    
    # 2. Dynamically add n columns for the metrics  
    # We loop through metrics_keys and extract the value from the 'multipliers' list  
    for(k in metrics_keys) {  
      # Clean up the column name for display (optional: removes 'model_inputs.')  
      display_name <- gsub("model_inputs.", "", k)  
      df[[display_name]] <- sapply(lib, function(x) {  
        # Access the multiplier for this specific key  
        val <- x$multipliers[[k]]  
        # Return formatted value (e.g., 1.05)  
        return(round(val, 2))  
      })  
    }  
    # 3. Combine the list into a data frame  
    df <- as.data.frame(df)  
    
    datatable(df, selection = 'multiple', options = list(pageLength = 5))
  })
  
  # --- LOGIC: BATCH RUN ---
  observeEvent(input$run_batch, {
    
    # --- ENGINE INITIALIZATION ---
    # Ensure your engine is initialized here
    # engine <- risk.resilience.quantifier$new("config.yaml", "goModel", "States")
    engine <- risk.resilience.quantifier$new(
      config_path = CONFIG_PATH,
      target_model_name = MODEL_NAME,
      target_subsector = input$portfolio_selector
    )

    input_data_fil <- headroom_data()
    input_data_fil <- input_data_fil %>% select(Entity_Name, Country, State, Analyst, ASID, SPID, CSID, FIPS, Sector, Portfolio, 
                                                Net_Direct_Debt_Per_Capita, Net_Direct_Debt_Per_Capita_Score, Cost_for_Debt_and_Liabilities, 
                                                Cost_for_Debt_and_Liabilities_Score, Budget_based_reserve_as_pct_Annual_Revenues, Reserves_Initial_Score)

    base_data <- input_data_fil %>%
      mutate(
        Entity_Name = as.character(Entity_Name),
        Country = as.character(Country),
        State = as.character(State),
        Analyst = as.character(Analyst),
        Sector = as.character(Sector),
        Portfolio = as.character(Portfolio),
        ASID = as.character(ASID),
        SPID = as.character(SPID),
        CSID = as.character(CSID),
        FIPS = as.character(FIPS),
        Net_Direct_Debt_Per_Capita = as.numeric(as.character(Net_Direct_Debt_Per_Capita)),
        Net_Direct_Debt_Per_Capita_Score = as.numeric(as.character(Net_Direct_Debt_Per_Capita_Score)),
        Cost_for_Debt_and_Liabilities = as.numeric(as.character(Cost_for_Debt_and_Liabilities)),
        Cost_for_Debt_and_Liabilities_Score = as.numeric(as.character(Cost_for_Debt_and_Liabilities_Score)),
        Budget_based_reserve_as_pct_Annual_Revenues = as.numeric(as.character(Budget_based_reserve_as_pct_Annual_Revenues)),
        Reserves_Initial_Score = as.numeric(as.character(Reserves_Initial_Score))
      )

    
    #base_data <- input_data
    # --- DATA SETUP ---
    # base_data <- data.table(
    #   SPID = paste0("ID_", 1:10),
    #   `model_inputs.dpdebttaxsupdpercap` = c(1000, 1450, 2000, 3600, 4500, 4600, 100, 2500, 3500, 5000),
    #   `model_outputs.dpdebtscore`      = c(2, 2, 2, 4, 5, 6, 1, 3, 4, 5),
    #   `model_inputs.dpaicmetric`       = c(0.04, 0.055, 0.05, 0.13, 0.14, 0.16, 0.02, 0.08, 0.11, 0.16),
    #   `model_outputs.dpaicscore`       = c(2, 2, 2, 4, 5, 6, 1, 3, 4, 5),
    #   `model_inputs.flexfbpercent`     = c(0.08, 0.045, 0.03, 0.015, 0.005, 0.001, 0.10, 0.05, 0.02, 0.005),
    #   `model_outputs.flexinitscore`    = c(1, 2, 2, 3, 4, 4, 1, 2, 3, 4)
    # )
    # 
    
    

    
    
    lib <- scenario_registry$registry
    selected_rows <- input$library_table_rows_selected
    if(length(selected_rows) == 0) {
      showNotification("Please select scenarios from the table.", type = "error")
      return()
    }
    if (is.null(engine)) {
      showNotification("Engine not initialized.", type = "error")
      return()
    }
    
    selected_ids <- names(lib)[selected_rows]
    
    withProgress(message = 'Running Quantifier Engine...', value = 0, {
      all_results <- list()
      n <- length(selected_ids)
      for(i in seq_along(selected_ids)) {
        id <- selected_ids[i]
        s_name <- lib[[id]]$name
        s_map <- lib[[id]]$multipliers
        res <- engine$run_scenario_analysis(base_data, s_map, s_name)
        all_results[[i]] <- res
        incProgress(1/n)
      }
      batch_output(rbindlist(all_results, fill = TRUE))
    })
    updateTabItems(session, "main", "results")
  })
  
  # --- OUTPUTS: RESULTS ---
  
  # FIXED: Corrected the loop for formatStyle
  output$master_table <- renderDT({
    req(batch_output())
    res_dt <- batch_output()
    
    # Find all columns that end in _status
    status_cols <- grep("_status$", names(res_dt), value = TRUE)
    
    # Initialize the datatable object
    res_dt <- res_dt %>% relocate(scenario_label, ASID, Entity_Name, .before = 1)
    
    dt_obj <- DT::datatable(
      res_dt,
      filter = 'top', rownames = FALSE, extensions = c('Buttons','FixedColumns',"FixedHeader"),
      options = list(
        dom = 'Blfrtip',
        buttons = c('copy', 'excel', 'pdf'),
        scrollX = TRUE,
        paging = TRUE,
        scrollY = 400,   
        scrollCollapse = TRUE,     
        #fixedHeader = TRUE,
        fixedColumns = list(leftColumns = 3, rightColumns = 0),
        lengthMenu = list(c(10, 25, 50, 100, -1), c('10', '25', '50', '100', 'All')),
        initComplete = JS("function(settings, json) {","$(this.api().table().header()).css({'font-size': '14px'});","}"),
        pageLength = 100))
    
    # Apply formatting to the DT object iteratively
    if(length(status_cols) > 0) {
      for(col in status_cols) {
        dt_obj <- formatStyle(dt_obj, col,
                              backgroundColor = styleEqual(c("Safe", "Breached"), c('#d4edda', '#f8d7da')))
      }
    }
    dt_obj
  })
  
  # FIXED: Corrected the grouping logic for Plotly
  output$batch_dist_plot_nddpc <- renderPlotly({
    req(batch_output())
    res_dt <- batch_output()
    
    # Find the first available headroom category column - NDDPC in this case
    cat_col <- grep("_headroom_category$", names(res_dt), value = TRUE)[1]
    
    if(is.na(cat_col)) return(NULL)
    
    # Use standard data.table syntax instead of !!sym() to avoid evaluation errors
    plot_df <- res_dt[, .N, by = .(scenario_label, category = get(cat_col))]
    
    p <- ggplot(plot_df, aes(x = category, y = N, fill = scenario_label)) +
      geom_bar(stat = "identity", position = "dodge") +
      theme_minimal() +
      labs(x = "Risk Category", y = "Count", fill = "Scenario")
    
    ggplotly(p)
  })
  
  output$batch_dist_plot_cdl <- renderPlotly({
    req(batch_output())
    res_dt <- batch_output()
    
    # Find the second available headroom category column - CDL in this case
    cat_col <- grep("_headroom_category$", names(res_dt), value = TRUE)[2]
    
    if(is.na(cat_col)) return(NULL)
    
    # Use standard data.table syntax instead of !!sym() to avoid evaluation errors
    plot_df <- res_dt[, .N, by = .(scenario_label, category = get(cat_col))]
    
    p <- ggplot(plot_df, aes(x = category, y = N, fill = scenario_label)) +
      geom_bar(stat = "identity", position = "dodge") +
      theme_minimal() +
      labs(x = "Risk Category", y = "Count", fill = "Scenario")
    
    ggplotly(p)
  })
  
  output$batch_dist_plot_reserves <- renderPlotly({
    req(batch_output())
    res_dt <- batch_output()
    
    # Find the third available headroom category column - Reserves in this case
    cat_col <- grep("_headroom_category$", names(res_dt), value = TRUE)[3]
    
    if(is.na(cat_col)) return(NULL)
    
    # Use standard data.table syntax instead of !!sym() to avoid evaluation errors
    plot_df <- res_dt[, .N, by = .(scenario_label, category = get(cat_col))]
    
    p <- ggplot(plot_df, aes(x = category, y = N, fill = scenario_label)) +
      geom_bar(stat = "identity", position = "dodge") +
      theme_minimal() +
      labs(x = "Risk Category", y = "Count", fill = "Scenario")
    
    ggplotly(p)
  })
  
  output$total_rows <- renderValueBox({
    req(batch_output())
    valueBox(nrow(batch_output()), "Total Data Points", icon = icon("database"), color = "blue")
  })
  
  output$total_breaches <- renderValueBox({
    req(batch_output())
    res_dt <- batch_output()
    status_cols <- grep("_status$", names(res_dt), value = TRUE)
    if(length(status_cols) == 0) return(valueBox(0, "Breaches", icon = icon("exclamation-triangle"), color = "red"))
    
    # Sum breaches in the first status column found
    val <- sum(res_dt[[status_cols[1]]] == "Breached", na.rm = TRUE)
    valueBox(val, "Total Breaches", icon = icon("exclamation-triangle"), color = "red")
  })
  
  output$scenarios_run <- renderValueBox({
    req(batch_output())
    val <- length(unique(batch_output()$scenario_label))
    valueBox(val, "Scenarios Processed", icon = icon("check"), color = "green")
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
