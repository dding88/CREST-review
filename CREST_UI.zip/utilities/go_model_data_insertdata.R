library(govutils)
library(mdu)
library(ipfnfp)
library(dplyr)
library(purrr)
library(DT)
library(magrittr)
library(tidyr)
library(ipfnfpdu)
library(data.table)
library(jsonlite)
library(aws.s3)
library(parallel)
#detach('package:govutils', unload=TRUE)
#Sys.setenv(GOVUTILS_CONFIG = "PROD")
library(RPostgreSQL)
#library(RPostgres)
library(DBI)
library(readxl)


portfolio_types <- c("TaxSec-GO_Municipalities","TaxSec-GO_Counties","States-States")


govutils::switch_env_verbose(env = "production", verbose = "ON", verbose_okta = "OFF")
pool <- govutils::pg_connect()
query_portfolio <- paste0("WHERE \"PORTFOLIO_TYPE\" in ('TaxSec-GO_Municipalities','TaxSec-GO_Counties','States-States')")
secid_query <- paste0('SELECT * FROM gov."USPF_SEC_ID" ',query_portfolio)
query_data <- DBI::dbGetQuery(pool, secid_query)
govutils::pg_disconnect(pool) 

states_metadata <- query_data %>% filter(PORTFOLIO_TYPE == "States-States")
munis_metadata <- query_data %>% filter(PORTFOLIO_TYPE == "TaxSec-GO_Municipalities")
counties_metadata <- query_data %>% filter(PORTFOLIO_TYPE == "TaxSec-GO_Counties")



#go_mdu_metadata <- govutils::search.mdu.by.modelid(1126) %>% filter(!user_name %in% c("test_user",NA))  %>% filter(status == "FIN")

pull_model_record <- function(key){
  record_data <- mdu::get.model.data(key)
}

# all_mdu_records_full <- govutils::get_mdu_index(
#   model_id = 1126, env = "prod"
# )

all_mdu_records_states <- govutils::get_mdu_index(
  model_id = 1126, env = "prod"
) %>% filter(asid %in% states_metadata$SECURITYID) %>%
   filter(!(user_name %in% c("whitney_jablonski", "squad_test", "olivia_perret","pre_backtesting")))

all_mdu_records_munis <- govutils::get_mdu_index(
  model_id = 1126, env = "prod"
) %>% filter(asid %in% munis_metadata$SECURITYID) %>%
  filter(!(user_name %in% c("whitney_jablonski", "squad_test", "olivia_perret","pre_backtesting")))

all_mdu_records_counties <- govutils::get_mdu_index(
  model_id = 1126, env = "prod"
) %>% filter(asid %in% counties_metadata$SECURITYID) %>%
  filter(!(user_name %in% c("whitney_jablonski", "squad_test", "olivia_perret","pre_backtesting")))


latest_key_states <- all_mdu_records_states %>%
  group_by(spid) %>%
  slice_max(order_by = date, n = 1) %>% pull(key)

latest_key_munis <- all_mdu_records_munis %>%
  group_by(spid) %>%
  slice_max(order_by = date, n = 1) %>% pull(key)

latest_key_counties <- all_mdu_records_counties %>%
  group_by(spid) %>%
  slice_max(order_by = date, n = 1) %>% pull(key)


record_data_states <- lapply(latest_key_states,mdu::get.model.data)

record_data_munis <- lapply(latest_key_munis,mdu::get.model.data)

record_data_counties <- lapply(latest_key_counties,mdu::get.model.data)

create_df <- function(rec){
  econ_data <- unlist(rec[c])
  unwrapped_table <-  as.data.frame(t(unlist(rec[c("entity_name","country","spid","org_id", "credit_identifiers","sector","user_name","econ","model_inputs","model_outputs")])))
}


latest_testing_data_states <- map_df(record_data_states, create_df)
latest_testing_data_munis <- map_df(record_data_munis, create_df)
latest_testing_data_counties <- map_df(record_data_counties, create_df)

openxlsx::write.xlsx(latest_testing_data_states ,"./CreditResilienceTool/GO/GO_States.xlsx")
write.csv(latest_testing_data_munis ,"./CreditResilienceTool/GO/GO_Munis.csv")
openxlsx::write.xlsx(latest_testing_data_counties ,"./CreditResilienceTool/GO/GO_Counties.xlsx")

df_states <- read_xlsx("./CreditResilienceTool/GO/GO_States.xlsx")
#df_states <- latest_testing_data_states
df_states_params <- df_states %>%
  filter(!is.na(entity_name)) %>% 
  select(entity_name,country,econ.state,user_name,credit_identifiers.asid, credit_identifiers.spid, credit_identifiers.csid, credit_identifiers.geo_id,
        sector, model_inputs.portfolio, model_inputs.dpdebttaxsupdpercap, model_outputs.dpdebtscore, 
         model_inputs.dpaicmetric, model_outputs.dpaicscore, model_inputs.flexfbpercent, model_outputs.flexinitscore) %>%
  mutate(credit_identifiers.asid = as.numeric(credit_identifiers.asid)) %>%
  mutate(record_time_stamp = as.character(Sys.time())) %>%
  rename('Entity_Name' = entity_name,
         'Country' = country,
         'State' = econ.state,
         'Analyst' = user_name,
         'ASID' = credit_identifiers.asid,
         'SPID' = credit_identifiers.spid,
         'CSID' = credit_identifiers.csid,
         'FIPS' = credit_identifiers.geo_id,
         'Sector' = sector,
         'Portfolio' = model_inputs.portfolio,
         'Net_Direct_Debt_Per_Capita' = model_inputs.dpdebttaxsupdpercap,
         'Net_Direct_Debt_Per_Capita_Score' = model_outputs.dpdebtscore,
         'Cost_for_Debt_and_Liabilities' = model_inputs.dpaicmetric,
         'Cost_for_Debt_and_Liabilities_Score' = model_outputs.dpaicscore,
         'Budget_based_reserve_as_pct_Annual_Revenues' = model_inputs.flexfbpercent,
         'Reserves_Initial_Score' = model_outputs.flexinitscore,
         'Timestamp' =record_time_stamp) 


############## - munis mnemonics are different. confirm that (it could be for reserves data)
#df_munis <- read.csv("./GO/GO_Munis.csv")
df_munis <- latest_testing_data_munis
df_munis_params <- df_munis %>%
  filter(!is.na(entity_name)) %>% 
  select(entity_name, country,econ.state, user_name, credit_identifiers.asid, credit_identifiers.spid, credit_identifiers.csid, credit_identifiers.geo_id,
         sector, model_inputs.portfolio, model_inputs.dpdebttaxsupdpercap, model_outputs.dpdebtscore, 
         model_inputs.dpaicmetric, model_outputs.dpaicscore, model_inputs.flexfbpercent, model_outputs.flexinitscore) %>% 
  mutate(credit_identifiers.asid = as.numeric(credit_identifiers.asid)) %>%
  mutate(record_time_stamp = as.character(Sys.time())) %>%
  rename('Entity_Name' = entity_name,
         'Country' = country,
         'State' = econ.state,
         'Analyst' = user_name,
         'ASID' = credit_identifiers.asid,
         'SPID' = credit_identifiers.spid,
         'CSID' = credit_identifiers.csid,
         'FIPS' = credit_identifiers.geo_id,
         'Sector' = sector,
         'Portfolio' = model_inputs.portfolio,
         'Net_Direct_Debt_Per_Capita' = model_inputs.dpdebttaxsupdpercap,
         'Net_Direct_Debt_Per_Capita_Score' = model_outputs.dpdebtscore,
         'Cost_for_Debt_and_Liabilities' = model_inputs.dpaicmetric,
         'Cost_for_Debt_and_Liabilities_Score' = model_outputs.dpaicscore,
         'Budget_based_reserve_as_pct_Annual_Revenues' = model_inputs.flexfbpercent,
         'Reserves_Initial_Score' = model_outputs.flexinitscore,
         'Timestamp' =record_time_stamp)

##############

#df_counties <- read_xlsx("./GO/GO_Counties.xlsx")
df_counties <- latest_testing_data_counties
df_counties_params <- df_counties %>%
  filter(!is.na(entity_name)) %>% 
  select(entity_name, country,econ.state,user_name, credit_identifiers.asid, credit_identifiers.spid, credit_identifiers.csid, credit_identifiers.geo_id,
         sector,  model_inputs.portfolio, model_inputs.dpdebttaxsupdpercap, model_outputs.dpdebtscore, 
         model_inputs.dpaicmetric, model_outputs.dpaicscore, model_inputs.flexfbpercent, model_outputs.flexinitscore) %>% 
  mutate(credit_identifiers.asid = as.numeric(credit_identifiers.asid)) %>%
  mutate(record_time_stamp = as.character(Sys.time())) %>%
  rename('Entity_Name' = entity_name,
         'Country' = country,
         'State' = econ.state,
         'Analyst' = user_name,
         'ASID' = credit_identifiers.asid,
         'SPID' = credit_identifiers.spid,
         'CSID' = credit_identifiers.csid,
         'FIPS' = credit_identifiers.geo_id,
         'Sector' = sector,
         'Portfolio' = model_inputs.portfolio,
         'Net_Direct_Debt_Per_Capita' = model_inputs.dpdebttaxsupdpercap,
         'Net_Direct_Debt_Per_Capita_Score' = model_outputs.dpdebtscore,
         'Cost_for_Debt_and_Liabilities' = model_inputs.dpaicmetric,
         'Cost_for_Debt_and_Liabilities_Score' = model_outputs.dpaicscore,
         'Budget_based_reserve_as_pct_Annual_Revenues' = model_inputs.flexfbpercent,
         'Reserves_Initial_Score' = model_outputs.flexinitscore,
         'Timestamp' =record_time_stamp)




cred <- methutils::get_secret_manager_keys(list("DB.POSTGRES.METHODOLOGIES.GOV_USER"),env="dev")
# Establish connection
con <- DBI::dbConnect(
  drv = RPostgreSQL::PostgreSQL(),
  port = "5432",
  dbname = "methodologies",
  host = "pstg-dev-1b-db1.dev.rtg.awsspgi",
  user = "gov_user",
  password = cred$data$DB.POSTGRES.METHODOLOGIES.GOV_USER
)

#insertdata <- DBI::dbExecute(con, query_states_insert, params = as.list(df_states_params))
# 2. Define the target
target_schema <- "gov"
target_table  <- "risq_go_states"

# 3. Execution Block
# We use a standard try block without the fancy DBI checks that RPostgreSQL hates
tryCatch({
  # 1. Attempt the upload
  # We use append=TRUE because you lack CREATE permissions in the schema
  dbWriteTable(
    con, 
    name = c("gov","risq_go_states"), 
    #schema = "gov", 
    value = df_states_params,
    append = TRUE,
    row.names = FALSE
  )
  
  message("✅ Data copied successfully!")
  
}, error = function(e) {
  # 2. Only print the error; do NOT disconnect here
  message("❌ Error copying data: ", e$message)
  
}, finally = {
  # 3. The 'finally' block runs NO MATTER WHAT (success or error)
  # This is the safest place to disconnect.
  if (exists("con")) {
    DBI::dbDisconnect(con)
    message("🔌 Database connection closed.")
  }
})

target_table  <- "risq_go_counties"

con <- DBI::dbConnect(
  drv = RPostgreSQL::PostgreSQL(),
  port = "5432",
  dbname = "methodologies",
  host = "pstg-dev-1b-db1.dev.rtg.awsspgi",
  user = "gov_user",
  password = cred$data$DB.POSTGRES.METHODOLOGIES.GOV_USER
)

# 3. Execution Block
# We use a standard try block without the fancy DBI checks that RPostgreSQL hates
tryCatch({
  # 1. Attempt the upload
  # We use append=TRUE because you lack CREATE permissions in the schema
  dbWriteTable(
    con, 
    name = c("gov","risq_go_counties"), 
    #schema = "gov", 
    value = df_counties_params,
    append = TRUE,
    row.names = FALSE
  )
  
  message("✅ Data copied successfully!")
  
}, error = function(e) {
  # 2. Only print the error; do NOT disconnect here
  message("❌ Error copying data: ", e$message)
  
}, finally = {
  # 3. The 'finally' block runs NO MATTER WHAT (success or error)
  # This is the safest place to disconnect.
  if (exists("con")) {
    DBI::dbDisconnect(con)
    message("🔌 Database connection closed.")
  }
})

target_table  <- "risq_go_munis"

con <- DBI::dbConnect(
  drv = RPostgreSQL::PostgreSQL(),
  port = "5432",
  dbname = "methodologies",
  host = "pstg-dev-1b-db1.dev.rtg.awsspgi",
  user = "gov_user",
  password = cred$data$DB.POSTGRES.METHODOLOGIES.GOV_USER
)

# 3. Execution Block
# We use a standard try block without the fancy DBI checks that RPostgreSQL hates
tryCatch({
  # 1. Attempt the upload
  # We use append=TRUE because you lack CREATE permissions in the schema
  dbWriteTable(
    con, 
    name = c("gov","risq_go_munis"), 
    #schema = "gov", 
    value = df_munis_params,
    append = TRUE,
    row.names = FALSE
  )
  
  message("✅ Data copied successfully!")
  
}, error = function(e) {
  # 2. Only print the error; do NOT disconnect here
  message("❌ Error copying data: ", e$message)
  
}, finally = {
  # 3. The 'finally' block runs NO MATTER WHAT (success or error)
  # This is the safest place to disconnect.
  if (exists("con")) {
    DBI::dbDisconnect(con)
    message("🔌 Database connection closed.")
  }
})

