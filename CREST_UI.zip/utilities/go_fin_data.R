library(tidyverse)
library(lubridate)


# 
# df <- govutils::get.financial.data(50492,
#                          source = "rap",
#                          seq_years = c(0,15),
#                          stmt_basis = 'all')

#Figure out how to get CSID from ASID - need that mapping

#use CSID in the function here
df_guam <- govutils::get.financial.data(as.numeric(5511),
                                        source = "rap",
                                        seq_years = c(0,15),
                                        stmt_basis = 'all') |>
  mutate(year = year(periodEndDate), .keep = "all", .after = periodEndDate) |>
  mutate(APRAcceptable = ifelse(is.na(APRAcceptable), "false", APRAcceptable)) |>
  mutate(rank = (case_match(tolower(APRAcceptable),
                            "true" ~ 1000,
                            "false" ~ 0,
                            .default = 0) +
                   case_match(tolower(STMT_TYPE),
                              "audited" ~ 100,
                              "unaudited apr acceptable" ~ 90,
                              "unaudited" ~ 80,
                              "projected" ~ 70,
                              "budgeted" ~ 60,
                              "data_only" ~ 50,
                              #so it's just a guess from here (though may not be relative for GO)
                              "actual" ~ 40,
                              "estimate" ~ 30,
                              "accural" ~ 20,
                              "demand data" ~ 10,
                              "cash" ~ 5,
                              .default = 0)
  ), .keep = "all") |>
  arrange(desc(rank)) |> arrange(desc(year)) |>
  unique(by = "year") |>
  select(
    orgIdType, orgId, periodEndDate, year,
    TotCurCostToTotGovFdRevPercentGOState,
    NetDirectDPerCapGOState,
    LatestPopulationGOState
  ) |>
  as_tibble()

########################

df_florida <- govutils::get.financial.data(as.numeric(8740),
                                           source = "rap",
                                           seq_years = c(0,15),
                                           stmt_basis = 'all') |>
  mutate(year = year(periodEndDate), .keep = "all", .after = periodEndDate) |>
  mutate(APRAcceptable = ifelse(is.na(APRAcceptable), "false", APRAcceptable)) |>
  mutate(rank = (case_match(tolower(APRAcceptable),
                            "true" ~ 1000,
                            "false" ~ 0,
                            .default = 0) +
                   case_match(tolower(STMT_TYPE),
                              "audited" ~ 100,
                              "unaudited apr acceptable" ~ 90,
                              "unaudited" ~ 80,
                              "projected" ~ 70,
                              "budgeted" ~ 60,
                              "data_only" ~ 50,
                              #so it's just a guess from here (though may not be relative for GO)
                              "actual" ~ 40,
                              "estimate" ~ 30,
                              "accural" ~ 20,
                              "demand data" ~ 10,
                              "cash" ~ 5,
                              .default = 0)
  ), .keep = "all") |>
  arrange(desc(rank)) |> arrange(desc(year)) |>
  unique(by = "year") |>
  select(
    orgIdType, orgId, periodEndDate, year,
    TotCurCostToTotGovFdRevPercentGOState,
    NetDirectDPerCapGOState,
    LatestPopulationGOState
  ) |>
  as_tibble()

########################

df_austin <- govutils::get.financial.data(as.numeric(2293),
                                          source = "rap",
                                          seq_years = c(0,15),
                                          stmt_basis = 'all') |>
  mutate(year = year(periodEndDate), .keep = "all", .after = periodEndDate) |>
  mutate(APRAcceptable = ifelse(is.na(APRAcceptable), "false", APRAcceptable)) |>
  mutate(rank = (case_match(tolower(APRAcceptable),
                            "true" ~ 1000,
                            "false" ~ 0,
                            .default = 0) +
                   case_match(tolower(STMT_TYPE),
                              "audited" ~ 100,
                              "unaudited apr acceptable" ~ 90,
                              "unaudited" ~ 80,
                              "projected" ~ 70,
                              "budgeted" ~ 60,
                              "data_only" ~ 50,
                              #so it's just a guess from here (though may not be relative for GO)
                              "actual" ~ 40,
                              "estimate" ~ 30,
                              "accural" ~ 20,
                              "demand data" ~ 10,
                              "cash" ~ 5,
                              .default = 0)
  ), .keep = "all") |>
  arrange(desc(rank)) |> arrange(desc(year)) |>
  unique(by = "year") |>
  select(
    orgIdType, orgId, periodEndDate, year,
    TotCurCostToTotGovFdRevPercentGOMC,
    NetDirDPerCapGOMC,
    LatestPopulationGOMC
  ) |>
  as_tibble()

