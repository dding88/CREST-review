library(govutils)
library(mdu)
library(ipfnfp)
library(dplyr)
library(purrr)
library(DT)
library(magrittr)
library(tidyr)
library(ipfnfpdu)
library(data.table)
library(jsonlite)
library(aws.s3)
library(parallel)
library(tictoc)
library(resq)

tictoc::tic()

portfolio_types <- c("TaxSec-GO_Municipalities","TaxSec-GO_Counties","States-States")


govutils::switch_env_verbose(env = "production", verbose = "ON", verbose_okta = "OFF")
pool <- govutils::pg_connect()
query_portfolio <- paste0("WHERE \"PORTFOLIO_TYPE\" in ('TaxSec-GO_Municipalities','TaxSec-GO_Counties','States-States')")
secid_query <- paste0('SELECT * FROM gov."USPF_SEC_ID" ',query_portfolio)
query_data <- DBI::dbGetQuery(pool, secid_query)
govutils::pg_disconnect(pool) 

states_metadata <- query_data %>% filter(PORTFOLIO_TYPE == "States-States")
munis_metadata <- query_data %>% filter(PORTFOLIO_TYPE == "TaxSec-GO_Municipalities")
counties_metadata <- query_data %>% filter(PORTFOLIO_TYPE == "TaxSec-GO_Counties")



#go_mdu_metadata <- govutils::search.mdu.by.modelid(1126) %>% filter(!user_name %in% c("test_user",NA))  %>% filter(status == "FIN")

pull_model_record <- function(key){
  record_data <- mdu::get.model.data(key)
}

# all_mdu_records_full <- govutils::get_mdu_index(
#   model_id = 1126, env = "prod"
# )

all_mdu_records_states <- govutils::get_mdu_index(
  model_id = 1126, env = "prod"
) %>% filter(asid %in% states_metadata$SECURITYID) %>%
   filter(!(user_name %in% c("whitney_jablonski", "squad_test", "olivia_perret","pre_backtesting")))

all_mdu_records_munis <- govutils::get_mdu_index(
  model_id = 1126, env = "prod"
) %>% filter(asid %in% munis_metadata$SECURITYID) %>%
  filter(!(user_name %in% c("whitney_jablonski", "squad_test", "olivia_perret","pre_backtesting")))

all_mdu_records_counties <- govutils::get_mdu_index(
  model_id = 1126, env = "prod"
) %>% filter(asid %in% counties_metadata$SECURITYID) %>%
  filter(!(user_name %in% c("whitney_jablonski", "squad_test", "olivia_perret","pre_backtesting")))


latest_key_states <- all_mdu_records_states %>%
  group_by(spid) %>%
  slice_max(order_by = date, n = 1) %>% pull(key)

latest_key_munis <- all_mdu_records_munis %>%
  group_by(spid) %>%
  slice_max(order_by = date, n = 1) %>% pull(key)

latest_key_counties <- all_mdu_records_counties %>%
  group_by(spid) %>%
  slice_max(order_by = date, n = 1) %>% pull(key)


record_data_states <- lapply(latest_key_states,mdu::get.model.data)

record_data_munis <- lapply(latest_key_munis,mdu::get.model.data)

record_data_counties <- lapply(latest_key_counties,mdu::get.model.data)

create_df <- function(rec){
  unwrapped_table <-  as.data.frame(t(unlist(rec[c("entity_name","country","spid","org_id", "credit_identifiers","sector","user_name","model_inputs","model_outputs")])))
}



latest_testing_data_states <- map_df(record_data_states, create_df)
latest_testing_data_munis <- map_df(record_data_munis, create_df)
latest_testing_data_counties <- map_df(record_data_counties, create_df)



openxlsx::write.xlsx(latest_testing_data_states ,"./CreditResilienceTool/GO/GO_States.xlsx")
write.csv(latest_testing_data_munis ,"./CreditResilienceTool/GO/GO_Munis.csv")
openxlsx::write.xlsx(latest_testing_data_counties ,"./CreditResilienceTool/GO/GO_Counties.xlsx")

tictoc::toc()