#' Title: Brief description of the function
#'
#' @description
#' A longer description of what the function does. Explain the purpose and any important details.
#'
#' @param param1 Description of the first parameter.
#' @param param2 Description of the second parameter (add as many as needed).
#'
#' @return Description of what the function returns (type and meaning).
#'
#' @details
#' Any additional details, such as edge cases, algorithmic notes, or references.
#'
#' @examples
#' # Basic usage example
#' result <- function_name(param1 = value1, param2 = value2)
#'
#' @seealso
#' \code{\link{related_function}} for related functionality.
#'
#' @export
pull_criteria_ranges <- function(metric, score) {
  # Function body goes here
  
  criteria_thresholds <- list(threshold = NA,range = NA)
  
  return(criteria_thresholds)
  
}

#' Title: Brief description of the function
#'
#' @description
#' A longer description of what the function does. Explain the purpose and any important details.
#'
#' @param param1 Description of the first parameter.
#' @param param2 Description of the second parameter (add as many as needed).
#'
#' @return Description of what the function returns (type and meaning).
#'
#' @details
#' Any additional details, such as edge cases, algorithmic notes, or references.
#'
#' @examples
#' # Basic usage example
#' result <- function_name(param1 = value1, param2 = value2)
#'
#' @seealso
#' \code{\link{related_function}} for related functionality.
#'
#' @export
calculate_headroom <- function(metric, score) {
  # Function body goes here
  headroom <- list(headroom_amt = NA,headroom_pct = NA)
  
  return(headroom)
  
}