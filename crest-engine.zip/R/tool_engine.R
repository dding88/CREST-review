Sys.setenv("_R_CHECK_SYSTEM_CLOCK_" = 0)
#' @title Risk Resilience Quantifier Engine
#'
#' @description
#' A high-performance R6 class designed to calculate the "Margin of Safety" (headroom)
#' for financial metrics. It determines how much a technical metric can deviate
#' before it triggers a change in its assigned credit/financial score based on
#' thresholds defined in a YAML configuration file.
#'
#' The engine is built on `data.table` for high-speed, in-place memory management,
#' making it suitable for large-scale batch processing and complex scenario analysis
#' (stress testing) across different subsectors (e.g., States, Counties, Municipalities).
#'
#' @import R6
#' @import data.table
#' @importFrom yaml read_yaml
#' @export
risk.resilience.quantifier <- R6::R6Class(
  "risk.resilience.quantifier",

  public = list(
    #' @field model_name Character. The name of the financial model (e.g., "goModel").
    model_name = NULL,

    #' @field subsector Character. The specific subsector being analyzed (e.g., "States").
    subsector = NULL,

    #' @field metrics_config List. The subset of the YAML configuration containing
    #' metric keys, display names, and scoring ladders for the active subsector.
    metrics_config = NULL,

    #' @description
    #' Initializes the engine by loading and validating the YAML configuration.
    #'
    #' @param config_path Character. The file path to the YAML configuration file.
    #' @param target_model_name Character. The expected model name. Must match the YAML.
    #' @param target_subsector Character. The subsector to load (e.g., "States", "Counties").
    #'
    #' @return An initialized `risk.resilience.quantifier` object.
    initialize = function(config_path, target_model_name, target_subsector) {
      full_config <- yaml::read_yaml(config_path)
      if (full_config$model_name != target_model_name) stop("Model mismatch.")
      if (!target_subsector %in% names(full_config)) stop("Subsector not found.")

      self$model_name <- target_model_name
      self$subsector <- target_subsector
      self$metrics_config <- full_config[[target_subsector]]$metrics_config
      message(paste0("Engine initialized: [", self$model_name, "] -> [", self$subsector, "]"))
    },

    #' @description
    #' Iterates through all metrics defined in the subsector configuration and
    #' appends headroom results to the provided data.
    calculate_all_headroom = function(data_input) {
      dt <- as.data.table(data_input)

      if (!"SPID" %in% names(dt)) {
        stop("Input data must contain a 'SPID' column.")
      }

      for (cfg in self$metrics_config) {
        display_name <- cfg$metric_display_name
        clean_name <- gsub("[[:space:].]+", "_", display_name)

        # 1. Get results (contains SPID + 4 new columns)
        res_dt <- self$calculate_headroom_vectorized(cfg, dt)

        # 2. Rename the 4 result columns to include the metric name
        # We do NOT rename SPID.
        setnames(res_dt,
                 old = c("available_headroom", "headroom_percentage", "headroom_category", "status"),
                 new = c(paste0(clean_name, "_headroom"),
                         paste0(clean_name, "_headroom_pct"),
                         paste0(clean_name, "_headroom_category"),
                         paste0(clean_name, "_status")))

        # 3. JOIN back to the main data using SPID
        # Instead of removing SPID, we merge the whole res_dt.
        # Since 'SPID' is the only common column, data.table will
        # automatically merge on it and not create 'SPID.x' or 'SPID.y'.
        dt <- merge(dt, res_dt, by = "SPID", all.x = TRUE)
      }

      return(dt)
    }   ,

    #' Perform Scenario Analysis via Metric Multipliers
    #'
    #' @description
    #' This method executes a scenario analysis by applying specific multipliers to a
    #' set of base metrics. It creates a non-destructive copy of the input data,
    #' applies the transformations in-place for computational efficiency, and
    #' recalculates all headroom metrics based on the adjusted values.
    #'
    #' @param base_data A `data.table` or `data.frame` containing the baseline
    #'   financial or operational metrics.
    #' @param scenario_map A named list where each name corresponds to a column
    #'   name in `base_data` and the value is a numeric multiplier (e.g., `list(revenue = 1.1, cost = 0.9)`).
    #' @param scenario_name A character string used to label the resulting
    #'   dataset (e.g., "Bull Case", "Stress Test").
    #'
    #' @return A `data.table` containing the recalculated headroom metrics,
    #'   augmented with a `scenario_label` column to distinguish it from the base case.
    #'
    #' @details
    #' The function performs the following steps:
    #' \enumerate{
    #'   \item Validates that the `scenario_map` length matches the internal
    #'   \code{metrics_config} to ensure all required metrics are accounted for.
    #'   \item Creates a deep copy of the input data to prevent side effects
    #'   on the original object.
    #'   \item Iterates through the map and applies multipliers using \code{data.table::set()}
    #'   for high-performance, in-place memory updates.
    #'   \item Invokes \code{self$calculate_all_headroom()} to derive new
    #'   analytical outputs from the modified data.
    #' }
    #'
    #' @note This function is optimized for large datasets by utilizing
    #' \code{data.table}'s in-place modification capabilities.
    #'
    #' @examples
    #' \dontrun{
    #' # Example usage within an R6 class context:
    #' scenario_map <- list(ebitda = 1.2, interest_expense = 1.05)
    #' results <- obj$run_scenario_analysis(base_dt, scenario_map, "Upside Scenario")
    #' }
    #'
    #' @export
    run_scenario_analysis = function(base_data, scenario_map, scenario_name) {
      if (length(scenario_map) != length(self$metrics_config)) {
        stop("Scenario Map length mismatch.")
      }

      # Create a deep copy to avoid mutating the original input_data
      scenario_dt <- copy(as.data.table(base_data))

      # Apply multipliers in-place using set() for maximum stability and speed
      for (m_key in names(scenario_map)) {
        if (m_key %in% names(scenario_dt)) {
          # Calculate the new values first
          new_values <- scenario_dt[[m_key]] * scenario_map[[m_key]]
          # Use set() to perform the in-place update safely
          data.table::set(scenario_dt, j = m_key, value = new_values)
        }
      }

      scenario_results <- self$calculate_all_headroom(scenario_dt)
      scenario_results[, scenario_label := scenario_name]
      return(scenario_results)
    },

    #' @description
    #' The computational core. Performs a vectorized calculation of headroom
    #' for all rows in a `data.table` simultaneously using a join.
    #'
    #' @param metric_cfg List. A single metric configuration element from the YAML.
    #' @param dt A `data.table` containing the technical and score columns.
    #'
    #' @return A `data.table` with 4 columns: `available_headroom`,
    #' `headroom_percentage`, `headroom_category`, and `status`.
    calculate_headroom_vectorized = function(metric_cfg, dt) {
      tech_metric_col <- metric_cfg$metric_key
      tech_score_col  <- metric_cfg$score_key

      # 1. Prepare Thresholds
      threshold_dt <- rbindlist(lapply(metric_cfg$score_thresholds, as.list))
      threshold_dt$score    <- as.numeric(threshold_dt$score)
      threshold_dt$threshold <- as.numeric(threshold_dt$threshold)
      threshold_dt$range     <- as.numeric(ifelse(threshold_dt$range == "NA", NA, threshold_dt$range))
      threshold_dt$operator  <- as.character(threshold_dt$operator)

      # 2. Create calculation table WITH SPID
      # Use get() to handle dynamic column names safely
      calc_dt <- dt[, .(SPID,
                        val = get(tech_metric_col),
                        score = get(tech_score_col))]

      # 3. Join thresholds to the data (Left Join)
      merged <- merge(calc_dt, threshold_dt, by = "score", all.x = TRUE)

      # 4. Initialize result vectors
      n <- nrow(merged)
      res_list <- list(
        SPID = merged$SPID,
        available_headroom = rep(NA_real_, n),
        headroom_percentage = rep(NA_real_, n),
        headroom_category = rep("At the lowest level", n),
        status = rep("Unknown", n)
      )

      # 5. Vectorized Logic
      valid_mask <- !is.na(merged$threshold)
      if (any(valid_mask)) {
        v_val <- merged$val[valid_mask]
        v_thresh <- merged$threshold[valid_mask]
        v_op <- merged$operator[valid_mask]
        v_range <- merged$range[valid_mask]
        
        headroom <- ifelse(v_op %in% c("<=", "<"),   
                           v_thresh - v_val,   
                           ifelse(v_op %in% c(">=", ">"),   
                                  v_val - v_thresh,   
                                  NA))

        is_safe <- rep(FALSE, length(v_val))

        for (op in unique(v_op)) {
          idx <- which(v_op == op)
          if (op %in% c("<=", "<")) {
            is_safe[idx] <- v_val[idx] <= v_thresh[idx]
          } else if (op %in% c(">=", ">")) {
            is_safe[idx] <- v_val[idx] >= v_thresh[idx]
          }
        }

        hp_pct <- ifelse(!is.na(v_range) & v_range > 0, headroom / v_range, NA_real_)

        res_list$available_headroom[valid_mask] <- ifelse(is_safe, headroom, -headroom)
        res_list$headroom_percentage[valid_mask] <- hp_pct
        res_list$status[valid_mask] <- ifelse(is_safe, "Safe", "Breached")
        res_list$headroom_category[valid_mask] <- ifelse(hp_pct <= 0.30, "Low",
                                                         ifelse(hp_pct <= 0.60, "Moderate", "High"))
      }

      # 6. Handle Score 6
      is_score_6 <- merged$score == 6
      res_list$status[is_score_6] <- "No Headroom Calculation possible - At Level 6"
      res_list$headroom_category[is_score_6] <- "At the lowest level"

      return(as.data.table(res_list))
    }
  )
)
