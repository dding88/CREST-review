library(shiny)
library(shinydashboard)
library(data.table)
library(DT)
library(plotly)
library(tidyverse)

# --- 1. ENGINE SETUP ---
# Mock version of the engine logic for demonstration
run_mock_engine <- function(base_data, scenario_map, scenario_name) {
  res <- copy(base_data)
  for(k in names(scenario_map)) {
    if(k %in% names(res)) res[[k]] <- res[[k]] * scenario_map[[k]]
  }
  # Simulate the engine's headroom calculations
  res[, `dpdebttaxsupdpercap_headroom_pct` := runif(.N, 0, 1)]
  res[, `dpdebttaxsupdpercap_headroom_category` := sample(c("Low", "Moderate", "High"), .N, replace=T)]
  res[, `dpdebttaxsupdpercap_status` := sample(c("Safe", "Breached"), .N, replace=T)]
  res[, scenario_label := scenario_name]
  return(res)
}

# --- 2. UI DESIGN ---
ui <- dashboardPage(
  skin = "black",
  dashboardHeader(title = "Risk Resilience Engine"),

  dashboardSidebar(
    sidebarMenu(
      menuItem("Scenario Builder", tabName = "builder", icon = icon("edit")),
      menuItem("Batch Results", tabName = "results", icon = icon("layer-group"))
    ),
    hr(),
    # SCENARIO CREATION PANEL
    tags$div(style = "padding: 15px;",
             h4("1. Define Scenario", style = "color: white;"),
             textInput("scen_name", "Scenario Name", placeholder = "e.g. High Debt Stress"),
             uiOutput("builder_sliders"),
             actionButton("save_scen", "Add to Library",
                          icon = icon("plus"),
                          style = "width: 100%; margin-top: 10px; background-color: #3498db; color: white;")
    )
  ),

  dashboardBody(
    tabItems(
      # TAB 1: THE LIBRARY
      tabItem(tabName = "builder",
              fluidRow(
                box(title = "Scenario Library", width = 12, status = "primary", solidHeader = TRUE,
                    helpText("Build scenarios on the left, then save them here. Select scenarios to run in batch."),
                    DTOutput("library_table"),
                    hr(),
                    actionButton("run_batch", "RUN ALL SELECTED SCENARIOS",
                                 icon = icon("bolt"),
                                 style = "width: 100%; height: 50px; font-size: 18px; background-color: #2ecc71; color: white;")
                )
              )
      ),

      # TAB 2: BATCH RESULTS & COMPARISON
      tabItem(tabName = "results",
              fluidRow(
                valueBoxOutput("total_rows", width = 4),
                valueBoxOutput("total_breaches", width = 4),
                valueBoxOutput("scenarios_run", width = 4)
              ),
              fluidRow(
                box(title = "Master Batch Report (All Scenarios Combined)", width = 12, status = "primary",
                    DTOutput("master_table"))
              ),
              fluidRow(
                box(title = "Risk Distribution Comparison", width = 12, status = "warning",
                    plotlyOutput("batch_dist_plot"))
              )
      )
    )
  )
)

# --- 3. SERVER LOGIC ---
server <- function(input, output, session) {

  # --- DATA & STATE ---
  base_data <- data.table(
    `model_inputs.dpdebttaxsupdpercap` = c(1000, 1450, 2000, 3600, 4500, 4600, 100, 2500, 3500, 5000),
    `model_outputs.dpdebtscore`      = c(2, 2, 2, 4, 5, 6, 1, 3, 4, 5),
    `model_inputs.dpaicmetric`       = c(0.04, 0.055, 0.05, 0.13, 0.14, 0.16, 0.02, 0.08, 0.11, 0.16),
    `model_outputs.dpaicscore`       = c(2, 2, 2, 4, 5, 6, 1, 3, 4, 5),
    `model_inputs.flexfbpercent`     = c(0.08, 0.045, 0.03, 0.015, 0.005, 0.001, 0.10, 0.05, 0.02, 0.005),
    `model_outputs.flexinitscore`    = c(1, 2, 2, 3, 4, 4, 1, 2, 3, 4)
  )

  metrics_keys <- c("model_inputs.dpdebttaxsupdpercap", "model_inputs.dpaicmetric", "model_inputs.flexfbpercent")

  # REACTIVE STATE
  scenario_registry <- reactiveValues(registry = list())
  batch_output <- reactiveVal(NULL)

  # FIXED: Added the missing reactive counter
  scenario_counter <- reactiveVal(0)

  # --- INITIALIZATION ---
  observe({
    default_mults <- setNames(rep(1.0, length(metrics_keys)), metrics_keys)
    # Initialize with "base" as a special protected key
    scenario_registry$registry[["base"]] <- list(
      name = "Base Case",
      multipliers = default_mults,
      type = "Base (Protected)"
    )
  })

  # --- UI GENERATION ---
  output$builder_sliders <- renderUI({
    lapply(metrics_keys, function(k) {
      sliderInput(paste0("slider_", k),
                  label = gsub("model_inputs.", "", k),
                  min = 0.1, max = 2.0, value = 1.0, step = 0.05)
    })
  })

  # --- LOGIC: ADD TO LIBRARY ---
  observeEvent(input$save_scen, {
    req(input$scen_name)

    # 1. Increment counter safely
    new_count <- scenario_counter() + 1
    scenario_counter(new_count)

    # 2. Create a unique ID (e.g., "scen_1") to prevent overwriting duplicate names
    new_id <- paste0("scen_", new_count)

    # 3. Collect slider values
    new_map <- list()
    for(k in metrics_keys) {
      new_map[[k]] <- input[[paste0("slider_", k)]]
    }

    # 4. Update the registry
    scenario_registry$registry[[new_id]] <- list(
      name = input$scen_name,
      multipliers = new_map,
      type = "Custom"
    )

    updateTextInput(session, "scen_name", value = "")
    showNotification(paste("Scenario", input$scen_name, "added!"), type = "message")
  })

  # --- LOGIC: DISPLAY LIBRARY ---
  output$library_table <- renderDT({
    lib <- scenario_registry$registry
    if(length(lib) == 0) return(datatable(data.frame(Status="No scenarios saved")))

    # Convert the list to a data frame for DT
    df <- data.frame(
      ID = names(lib),
      Scenario_Name = sapply(lib, function(x) x$name),
      Type = sapply(lib, function(x) x$type),
      stringsAsFactors = FALSE
    )
    datatable(df, selection = 'multiple', options = list(pageLength = 5))
  })

  # --- LOGIC: BATCH RUN ---
  observeEvent(input$run_batch, {
    lib <- scenario_registry$registry
    selected_rows <- input$library_table_rows_selected

    if(length(selected_rows) == 0) {
      showNotification("Please select scenarios from the table.", type = "error")
      return()
    }

    # Map selected row indices back to the registry keys (IDs)
    selected_ids <- names(lib)[selected_rows]

    withProgress(message = 'Running Scenario Engine...', value = 0, {
      all_results <- list()
      n <- length(selected_ids)

      for(i in seq_along(selected_ids)) {
        id <- selected_ids[i]
        s_name <- lib[[id]]$name
        s_map <- lib[[id]]$multipliers

        res <- run_mock_engine(base_data, s_map, s_name)
        all_results[[i]] <- res
        incProgress(1/n)
      }
      batch_output(rbindlist(all_results))
    })

    # Switch to results tab
    updateTabItems(session, "main", "results")
  })

  # --- OUTPUTS: RESULTS ---
  output$master_table <- renderDT({
    req(batch_output())
    datatable(batch_output(),
              extensions = 'Buttons',
              options = list(dom = 'Bfrtip', buttons = c('copy', 'csv', 'excel'))) %>%
      formatStyle('dpdebttaxsupdpercap_status',
                  backgroundColor = styleEqual(c("Safe", "Breached"), c('#d4edda', '#f8d7da')))
  })

  output$batch_dist_plot <- renderPlotly({
    req(batch_output())
    plot_df <- batch_output()[, .N, by = .(scenario_label, dpdebttaxsupdpercap_headroom_category)]

    p <- ggplot(plot_df, aes(x = dpdebttaxsupdpercap_headroom_category, y = N, fill = scenario_label)) +
      geom_bar(stat = "identity", position = "dodge") +
      theme_minimal() +
      labs(x = "Risk Category", y = "Count", fill = "Scenario")

    ggplotly(p)
  })

  output$total_rows <- renderValueBox({
    req(batch_output())
    valueBox(nrow(batch_output()), "Total Data Points", icon = icon("database"), color = "blue")
  })

  output$total_breaches <- renderValueBox({
    req(batch_output())
    val <- sum(batch_output()$dpdebttaxsupdpercap_status == "Breached")
    valueBox(val, "Total Breaches", icon = icon("exclamation-triangle"), color = "red")
  })

  output$scenarios_run <- renderValueBox({
    req(batch_output())
    val <- length(unique(batch_output()$scenario_label))
    valueBox(val, "Scenarios Processed", icon = icon("check"), color = "green")
  })
}

shinyApp(ui, server)
