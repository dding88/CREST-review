# ==============================================================================
# 1. PREPARATION
# ==============================================================================
library(data.table)
library(R6)
library(yaml)

# Load the class
# source("HeadroomEngine.R")

CONFIG_PATH <- "./inst/goModel.yml"
MODEL_NAME  <- "goModel"
SUBSECTOR   <- "States"

# ==============================================================================
# 2. CREATE MULTI-ROW INPUT TABLE (DATA.TABLE)
# ==============================================================================
input_data <- data.table(
  `model_inputs.dpdebttaxsupdpercap` = c(1000, 1450, 2000, 3600, 4500, 4600, 100, 2500, 3500, 5000),
  `model_outputs.dpdebtscore`      = c(2, 2, 2, 4, 5, 6, 1, 3, 4, 5),
  `model_inputs.dpaicmetric`       = c(0.04, 0.055, 0.05, 0.13, 0.14, 0.16, 0.02, 0.08, 0.11, 0.16),
  `model_outputs.dpaicscore`       = c(2, 2, 2, 4, 5, 6, 1, 3, 4, 5),
  `model_inputs.flexfbpercent`     = c(0.08, 0.045, 0.03, 0.015, 0.005, 0.001, 0.10, 0.05, 0.02, 0.005),
  `model_outputs.flexinitscore`    = c(1, 2, 2, 3, 4, 4, 1, 2, 3, 4)
)

# ==============================================================================
# 3. DEFINE SCENARIOS (USING DIRECT TECHNICAL KEYS)
# ==============================================================================
scenarios <- list(
  "Base Case" = list(
    "model_inputs.dpdebttaxsupdpercap" = 1,
    "model_inputs.dpaicmetric"         = 1,
    "model_inputs.flexfbpercent"       = 1
  ),

  "Stress: High Debt & Cost" = list(
    "model_inputs.dpdebttaxsupdpercap" = 1.30,
    "model_inputs.dpaicmetric"         = 1.50,
    "model_inputs.flexfbpercent"       = 1
  ),

  "Stress: Low Reserves" = list(
    "model_inputs.dpdebttaxsupdpercap" = 1,
    "model_inputs.dpaicmetric"         = 1,
    "model_inputs.flexfbpercent"       = 0.50
  ),

  "Extreme: Systemic Stress" = list(
    "model_inputs.dpdebttaxsupdpercap" = 1.50,
    "model_inputs.dpaicmetric"         = 1.50,
    "model_inputs.flexfbpercent"       = 0.20
  )
)

# ==============================================================================
# 4. EXECUTION ENGINE
# ==============================================================================
engine <- risk.resilience.quantifier$new(
  config_path = CONFIG_PATH,
  target_model_name = MODEL_NAME,
  target_subsector = SUBSECTOR
)

all_results_list <- list()
message(paste0("Starting Scenario Analysis for sector: ", SUBSECTOR))

for (s_name in names(scenarios)) {
  message(paste0("-> Running: ", s_name))

  # We treat Base Case the same as others to ensure the pipeline is identical
  # 1. Create a full map (Baseline 1.0 for all metrics in config, then overlay stress)
  full_tech_map <- setNames(rep(1.0, length(engine$metrics_config)),
                            sapply(engine$metrics_config, function(x) x$metric_key))

  # 2. Overlay the specific multipliers from the scenario
  for (k in names(scenarios[[s_name]])) {
    full_tech_map[[k]] <- scenarios[[s_name]][[k]]
  }

  res <- engine$run_scenario_analysis(
    base_data = input_data,
    scenario_map = full_tech_map,
    scenario_name = s_name
  )

  all_results_list[[s_name]] <- res
}

master_report <- rbindlist(all_results_list)
setcolorder(master_report, "scenario_label")

# ==============================================================================
# 5. OUTPUT
# ==============================================================================
cat("\n--- MASTER SCENARIO REPORT ---\n")
print(master_report)

cat("\n--- SUMMARY: HEADROOM % COMPARISON ---\n")
metric_cols <- grep("_headroom_pct$", names(master_report), value = TRUE)
summary_view <- master_report[, lapply(.SD, function(x) mean(x, na.rm = TRUE)),
                              by = scenario_label,
                              .SDcols = metric_cols]
print(summary_view)
