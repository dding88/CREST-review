library(dplyr)
library(tibble)

test_data <- tibble(
  `model_inputs.dpdebttaxsupdpercap` = c(500, 1450, 2000, 3600, 4500, 4600, 100, 2500, 3500, 5000),
  `model_outputs.dpdebtscore` = c(1, 2, 2, 4, 5, 6, 1, 3, 4, 5),
  `model_inputs.dpaicmetric` = c(0.03, 0.055, 0.05, 0.13, 0.14, 0.16, 0.02, 0.08, 0.11, 0.16),
  `model_outputs.dpaicscore` = c(1, 2, 2, 4, 5, 6, 1, 3, 4, 5),
  `model_inputs.flexfbpercent` = c(0.08, 0.045, 0.03, 0.015, 0.005, 0.001, 0.10, 0.05, 0.02, 0.005),
  `model_outputs.flexinitscore` = c(1, 2, 2, 3, 4, 4, 1, 2, 3, 4)
)

# --- 3. EXECUTION: Run the Engine ---
# Initialize the engine
engine <- risk.resilience.quantifier$new(
  config_path = "./inst/goModel.yml",
  target_model_name = "goModel",
  target_subsector = "States"
)

# Run the calculation
results <- engine$calculate_all_headroom(test_data)

# --- 3. VIEW RESULTS ---

# View the original data alongside the new headroom columns
print(results)

# Specifically check the headroom columns to verify naming convention
print("--- Headroom Columns Only ---")
print(results %>% select(contains("headroom")))
