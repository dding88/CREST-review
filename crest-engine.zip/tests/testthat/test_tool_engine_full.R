library(testthat)
library(data.table)
library(R6)
library(yaml)
library(here)
library(crest)


# source(here::here("R", "tool_engine.R"))
fixture_path <- here::here("inst","goModel.yml")
#list.files(path.expand("~"),pattern = "tool_engine.R",recursive = TRUE,full.names = TRUE)

#-------------------------------------------------------------------------------
# 1. Initialization
#-------------------------------------------------------------------------------


test_that("initialize() succeeds with correct model name and subsector",{
  eng <- risk.resilience.quantifier$new(fixture_path,"goModel","States")
  expect_equal(eng$model_name,"goModel")
  expect_equal(eng$subsector,"States")
  expect_length(eng$metrics_config,3)
})

test_that("initialize() errors on model name mismatch",{
  expect_error(
    risk.resilience.quantifier$new(fixture_path,"wrongModel","States"),
    "Model mismatch"
  )
})

test_that("initialize() errors when subsector is not found",{
 expect_error(risk.resilience.quantifier$new(fixture_path,"goModel","SchoolDistricts"),
              "Subsector not found") 
})

#-------------------------------------------------------------------------------
# 2. calculate_headroom_vectorized()  - debt per capita metric ("<="ladder)
# ------------------------------------------------------------------------------

eng_states <- risk.resilience.quantifier$new(fixture_path,"goModel","States")
debt_cfg   <- eng_states$metrics_config[[1]]
reserve_cfg <- eng_states$metrics_config[[3]]


test_that("'<=' operator: value comfortably under threshold is safe, high headroom",{
  dt <- data.table(
    SPID = "S1",
    model_inputs.dpdebttaxsupdpercap = 800,
    model_outputs.dpdebtscore = 2
  )
  
  res <- eng_states$calculate_headroom_vectorized(debt_cfg,dt)
  expect_equal(res$status,"Safe")
  expect_equal(res$available_headroom,abs(800-1500))
  expect_equal(res$headroom_percentage,700/1000)
  expect_equal(res$headroom_category,"High")
})


test_that("'<=' operator: value just over threshold is breached",{
  dt <- data.table(
    SPID = "S2",
    model_inputs.dpdebttaxsupdpercap = 1600,
    model_outputs.dpdebtscore = 2
  )
  
  res <- eng_states$calculate_headroom_vectorized(debt_cfg,dt)
  expect_equal(res$status,"Breached")
  expect_equal(res$available_headroom, 100)
  expect_equal(res$headroom_percentage,-0.1)
  expect_equal(res$headroom_category,"Low")
})


test_that("'<=' operator: value exactly at threshold is safe(boundary inclusive)",{
  dt <- data.table(
    SPID = "S3",
    model_inputs.dpdebttaxsupdpercap = 1500,
    model_outputs.dpdebtscore = 2
  )
  
  res <- eng_states$calculate_headroom_vectorized(debt_cfg,dt)
  expect_equal(res$status,"Safe")
  expect_equal(res$available_headroom,0)
  expect_equal(res$headroom_percentage,0)
  expect_equal(res$headroom_category,"Low")
})


test_that("category boundaries: 30% -> Low, 31% -> Moderate, 60% ->  Moderate, 61% -> High",{
  make_dt  <- function(val) data.table(
    SPID  = "X",
    model_inputs.dpdebttaxsupdpercap = val,
    model_outputs.dpdebtscore = 3
  )
   
  r30 <- eng_states$calculate_headroom_vectorized(debt_cfg,make_dt(2200))
  expect_equal(r30$headroom_category,"Low")
  
  r31 <- eng_states$calculate_headroom_vectorized(debt_cfg,make_dt(2190))
  expect_equal(r31$headroom_category,"Moderate")
  
  r60 <- eng_states$calculate_headroom_vectorized(debt_cfg,make_dt(1900))
  expect_equal(r60$headroom_category,"Moderate")
  
  r61 <- eng_states$calculate_headroom_vectorized(debt_cfg,make_dt(1890))
  expect_equal(r61$headroom_category,"High")
  
})


#-------------------------------------------------------------------------------
# 3. calculate_headroom_vectorized()  - reserves metric (">=" then "<=" ladder)
#-------------------------------------------------------------------------------

test_that("'>=' operator: value above threshold is safe",{
  dt <- data.table(
    SPID  = "R1",
    model_inputs.flexfbpercent  = 0.05,
    model_outputs.flexinitscore = 2
  )
  res <- eng_states$calculate_headroom_vectorized(reserve_cfg,dt)
  expect_equal(res$status,"Safe")
  expect_equal(round(res$available_headroom,4),0.01)
})


test_that("'>=' operator: value below threshold is breached",{
  dt <- data.table(
    SPID  = "R2",
    model_inputs.flexfbpercent  = 0.02,
    model_outputs.flexinitscore = 2
  )
  res <- eng_states$calculate_headroom_vectorized(reserve_cfg,dt)
  expect_equal(res$status,"Breached")
})


test_that("'<' operator:at score 4 (no range -> NA percentage) ",{
  dt <- data.table(
    SPID  = "R3",
    model_inputs.flexfbpercent  = 0.005,
    model_outputs.flexinitscore = 4
  )
  res <- eng_states$calculate_headroom_vectorized(reserve_cfg,dt)
  expect_equal(res$status,"Safe")
  expect_true(is.na(res$headroom_percentage))
})


#-------------------------------------------------------------------------------
# 4. Score 6 special case and unmatched score
#-------------------------------------------------------------------------------

test_that("score 6 returns 'No Headroom Calculation possible' regardless of operator",{
   m_col  <- debt_cfg[["metric_key"]]
   s_col  <- debt_cfg[["score_key"]]
  dt <-  data.table(SPID = "S6")
  dt[,(m_col) := 9999]
  dt[,(s_col) := 6L]
  
  res  <- eng_states$calculate_headroom_vectorized(debt_cfg,dt)
  expect_match(res$status,"No Headroom Calculation possible")
  expect_match(res$headroom_category, "At the lowest level")
})


test_that("a score with no matching threshold row returns Unknown / NA values",{
    m_col  <- debt_cfg[["metric_key"]]
    s_col  <- debt_cfg[["score_key"]]
    dt <-  data.table(SPID = "S7")
    dt[,(m_col) := 1000]
    dt[,(s_col) := 99L]
  
  res  <- eng_states$calculate_headroom_vectorized(debt_cfg,dt)
  expect_equal(res$status,"Unknown")
  expect_true(is.na(res$available_headroom))
  expect_true(is.na(res$headroom_percentage))
})


#-------------------------------------------------------------------------------
# 5. calculate_all_headroom() 
#-------------------------------------------------------------------------------

# Helper: build a minimal dt covering ALL metrics in eng_states config
# Each metric gets its metric_col = a safe value, score_col = score 2

make_full_dt <- function(spids = "M1"){
  dt <- data.table(SPID = spids)
  for (cfg in eng_states$metrics_config){
    m_col <- cfg[["metric_key"]]
    s_col <- cfg[["score_key"]]
    # Use score 2 safe values: debt = 800 (<= 1500, cost = 0.05(<= 0.06),reserves = 0.05(>= 0.04))
    safe_val <- switch(
      m_col,
      "model_inputs.dpdebttaxsupdpercap" =  rep(800, length(spids)),
      "model_inputs.dpaicmetric"         = rep(0.05,length(spids)),
      "model_inputs.flexfbpercent"  =     rep(0.05,length(spids)),
      "model_inputs.flexfbnongenpercent" = rep(0.05,length(spids)),
      rep(1,length(spids))
    )
    dt[,(m_col) := safe_val]
    dt[,(s_col) := 2L]
  }
  dt
}
test_that("calculate_all_headroom merges both metrics back onto the same SPID row",{
  dt <- make_full_dt("M1")
  res <- eng_states$calculate_all_headroom(dt)
  
  expect_equal(nrow(res),1)
  #Every metric should produce a _headroom and _status column
  
  for(cfg in eng_states$metrics_config){
    display <- gsub("[[:space:].]+","_",cfg[["metric_display_name"]])
    expect_true(paste0(display,"_headroom") %in% names(res),
                info = paste("Missing status col for",display))
    expect_true(paste0(display,"_status") %in% names(res),
                info = paste("Missing status col for",display))
  }
})

test_that("calculate_all_headroom errors when SPID columns is missing",{
  dt <- make_full_dt("X")
  dt[, SPID := NULL]
  expect_error(eng_states$calculate_all_headroom(dt),"SPID")
})



test_that("calculate_all_headroom handles multiple SPIDS independently(no row cross-walk)",{
  #Start from full safe dt, then override debt metric for entity B to be breached
  dt <- make_full_dt(c("A","B"))
  debt_m_col <- eng_states$metrics_config[[1]][["metric_key"]]
  dt[dt$SPID == "B",(debt_m_col) := 1600]
  
  res <- eng_states$calculate_all_headroom(dt)
  a_row <- res[SPID == "A"]
  b_row <- res[SPID == "B"]
  
  debt_display <- gsub("[[:space:].]+","_",eng_states$metrics_config[[1]][["metric_display_name"]])
  status_col  <- paste0(debt_display,"_status")
  
  expect_equal(a_row[[status_col]],"Safe")
  expect_equal(b_row[[status_col]],"Breached")
})


#-------------------------------------------------------------------------------
# 6. run_scenario_analysis() stress testing via multipliers 
#-------------------------------------------------------------------------------

make_neutral_map <- function(){
  m  <- lapply(eng_states$metrics_config, function(cfg)1.0)
  names(m) <- sapply(eng_states$metrics_config,function(cfg) cfg[["metric_key"]])
  m
}

test_that("run_scenario_analysis applies multipliers and flips a safe row to Breached",{
  base_dt  <- make_full_dt("SC1")
  debt_m_col  <- eng_states$metrics_config[[1]][["metric_key"]]
  base_dt[,(debt_m_col) := 1400] # Safe ar sxore 2 (threshold 1500)



# Stress: multiply debt by 1.2 -> 1400*1.2 = 1680 > 1500 -> Breached

scenario_map <- make_neutral_map()
scenario_map[[debt_m_col]] <- 1.2

res  <- eng_states$run_scenario_analysis(base_dt,scenario_map,"Stress Test")
debt_display <- gsub("[[:space:].]+","_",eng_states$metrics_config[[1]][["metric_display_name"]])
status_col <- paste0(debt_display,"_status")

expect_equal(unique(res$scenario_label),"Stress Test")
expect_equal(res[[status_col]],"Breached")


})


test_that("run_scenario_analysis does npt mutate teh original input data",{
  base_dt  <- make_full_dt("SC2")
  debt_m_col  <- eng_states$metrics_config[[1]][["metric_key"]]
  base_dt[,(debt_m_col) := 1400] # Safe ar sxore 2 (threshold 1500)
  original_value <- base_dt[[debt_m_col]]
  
  
  scenario_map <- make_neutral_map()
  scenario_map[[debt_m_col]] <- 1.2
  invisible(eng_states$run_scenario_analysis(base_dt,scenario_map,"Stress test"))
  
  expect_equal(base_dt[[debt_m_col]],original_value)

})


test_that("run_scenario_analysis error when scenario_map length doesnt match metrics_config",{
  base_dt  <- make_full_dt("SC3")
  bad_map  <- list(model_inputs.dpdebttaxsupdpercap = 1.2)  # length 1, config has 3 metrics
  expect_error(
    eng_states$run_scenario_analysis(base_dtbad_map,"Bad Scenario"),
    "Scenario Map length mismatch."
  )
})

test_that( "run_scenario_analysis correctly labels output with scenario_name",{

  base_dt <- make_full_dt("SC4")
  scenario_map  <- make_neutral_map()
  res <- eng_states$run_scenario_analysis(base_dt,scenario_map,"Bull Case")
  expect_equal(unique(res$scenario_label),"Bull Case")
})












































































